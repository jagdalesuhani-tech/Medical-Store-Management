package com.medical.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Cleaner {
    public static void main(String[] args) {
        try {
            // 1. Connect to DB
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/medical_store", "root", "root"); // CHANGE PASSWORD IF NEEDED
            Statement st = con.createStatement();

            // 2. Disable Safety
            st.execute("SET FOREIGN_KEY_CHECKS = 0");

            // 3. Drop Tables
            System.out.println("Deleting products...");
            st.execute("DROP TABLE IF EXISTS products");
            st.execute("DROP TABLE IF EXISTS product");
            
            System.out.println("Deleting categories...");
            st.execute("DROP TABLE IF EXISTS categories");
            st.execute("DROP TABLE IF EXISTS category");
            
            System.out.println("Deleting order_details...");
            st.execute("DROP TABLE IF EXISTS order_details");

            // 4. Re-enable Safety
            st.execute("SET FOREIGN_KEY_CHECKS = 1");
            
            System.out.println("DATABASE CLEANED SUCCESSFULLY!");
            con.close();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}