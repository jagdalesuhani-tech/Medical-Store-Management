package com.medical.entities;

import javax.persistence.*;

@Entity
@Table(name = "products") // Links to 'products' table
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "product_id") // Links to 'product_id'
    private int pId;

    @Column(name = "p_name")
    private String pName;
    
    @Column(name = "p_desc", length = 3000)
    private String pDesc;
    
    @Column(name = "p_photo")
    private String pPhoto;
    
    @Column(name = "p_price")
    private int pPrice;
    
    @Column(name = "p_discount")
    private int pDiscount;
    
    @Column(name = "p_quantity")
    private int pQuantity;

    @ManyToOne
    @JoinColumn(name = "category_id") // <--- IMPORTANT: Links to 'category_id' column in DB
    private Category category;

    public Product() {
    }

    public Product(String pName, String pDesc, String pPhoto, int pPrice, int pDiscount, int pQuantity, Category category) {
        this.pName = pName;
        this.pDesc = pDesc;
        this.pPhoto = pPhoto;
        this.pPrice = pPrice;
        this.pDiscount = pDiscount;
        this.pQuantity = pQuantity;
        this.category = category;
    }

    // Getters and Setters
    public int getpId() { return pId; }
    public void setpId(int pId) { this.pId = pId; }

    public String getpName() { return pName; }
    public void setpName(String pName) { this.pName = pName; }

    public String getpDesc() { return pDesc; }
    public void setpDesc(String pDesc) { this.pDesc = pDesc; }

    public String getpPhoto() { return pPhoto; }
    public void setpPhoto(String pPhoto) { this.pPhoto = pPhoto; }

    public int getpPrice() { return pPrice; }
    public void setpPrice(int pPrice) { this.pPrice = pPrice; }

    public int getpDiscount() { return pDiscount; }
    public void setpDiscount(int pDiscount) { this.pDiscount = pDiscount; }

    public int getpQuantity() { return pQuantity; }
    public void setpQuantity(int pQuantity) { this.pQuantity = pQuantity; }

    public Category getCategory() { return category; }
    public void setCategory(Category category) { this.category = category; }
}