package com.medical.entities;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_id")
    private int userId;

    @Column(name = "user_name")
    private String userName;

    @Column(name = "user_email", unique = true)
    private String userEmail;

    @Column(name = "user_password")
    private String userPassword;

    @Column(name = "user_phone")
    private String userPhone;

    @Column(name = "user_address", length = 1500)
    private String userAddress;

    @Column(name = "user_type")
    private String userType;

    @Column(name = "register_date")
    private Timestamp dateTime;

    // --- Constructors ---

    public User() {
    }

    // Constructor used by RegisterServlet (The one you needed!)
    public User(String userName, String userEmail, String userPassword, String userPhone, String userAddress, String userType) {
        this.userName = userName;
        this.userEmail = userEmail;
        this.userPassword = userPassword;
        this.userPhone = userPhone;
        this.userAddress = userAddress;
        this.userType = userType;
        this.dateTime = new Timestamp(System.currentTimeMillis()); // Sets current time automatically
    }

    // Full Constructor
    public User(int userId, String userName, String userEmail, String userPassword, String userPhone, String userAddress, String userType, Timestamp dateTime) {
        this.userId = userId;
        this.userName = userName;
        this.userEmail = userEmail;
        this.userPassword = userPassword;
        this.userPhone = userPhone;
        this.userAddress = userAddress;
        this.userType = userType;
        this.dateTime = dateTime;
    }

    // --- Getters and Setters ---

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public String getUserName() { return userName; }
    public void setUserName(String userName) { this.userName = userName; }

    public String getUserEmail() { return userEmail; }
    public void setUserEmail(String userEmail) { this.userEmail = userEmail; }

    public String getUserPassword() { return userPassword; }
    public void setUserPassword(String userPassword) { this.userPassword = userPassword; }

    public String getUserPhone() { return userPhone; }
    public void setUserPhone(String userPhone) { this.userPhone = userPhone; }

    public String getUserAddress() { return userAddress; }
    public void setUserAddress(String userAddress) { this.userAddress = userAddress; }

    public String getUserType() { return userType; }
    public void setUserType(String userType) { this.userType = userType; }

    public Timestamp getDateTime() { return dateTime; }
    public void setDateTime(Timestamp dateTime) { this.dateTime = dateTime; }

    @Override
    public String toString() {
        return "User{" + "userName='" + userName + '\'' + ", userEmail='" + userEmail + '\'' + '}';
    }
}