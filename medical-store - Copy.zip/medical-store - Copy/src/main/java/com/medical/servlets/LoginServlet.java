package com.medical.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.medical.dao.UserDao;
import com.medical.entities.User;
import com.medical.helper.FactoryProvider;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        try {
            // 1. Fetch data from login.jsp
            // MAKE SURE login.jsp has name="email" and name="password"
            String email = request.getParameter("email");
            String password = request.getParameter("password");

            // 2. Authenticate using DAO
            UserDao dao = new UserDao(FactoryProvider.getFactory());
            User user = dao.getUserByEmailAndPassword(email, password);

            // 3. Create Session
            HttpSession session = request.getSession();

            if (user == null) {
                // Login Failed
                session.setAttribute("message", "Invalid Email or Password! Try again.");
                response.sendRedirect("login.jsp");
            } else {
                // Login Success
                session.setAttribute("current-user", user);

                // 4. Role Based Redirection
                // Ensure 'userType' matches exactly what is in the database ('admin' or 'normal')
                if (user.getUserType().trim().equals("admin")) {
                    response.sendRedirect("admin/dashboard.jsp");
                } else {
                    response.sendRedirect("index.jsp"); 
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            HttpSession session = request.getSession();
            session.setAttribute("message", "Something went wrong: " + e.getMessage());
            response.sendRedirect("login.jsp");
        }
    }
}