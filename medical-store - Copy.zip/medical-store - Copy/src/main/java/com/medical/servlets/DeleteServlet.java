package com.medical.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.medical.dao.ProductDao;
import com.medical.dao.UserDao; // Make sure to import UserDao
import com.medical.helper.FactoryProvider;

@WebServlet("/DeleteServlet")
public class DeleteServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            // Get Parameters (One will be null, the other will have a value)
            String productId = request.getParameter("product_id");
            String userId = request.getParameter("user_id");
            
            // ==========================================
            // CASE 1: DELETE PRODUCT
            // ==========================================
            if (productId != null) {
                int pid = Integer.parseInt(productId);
                ProductDao dao = new ProductDao(FactoryProvider.getFactory());
                dao.deleteProduct(pid);
                
                request.getSession().setAttribute("message", "Product Deleted Successfully!");
            }
            
            // ==========================================
            // CASE 2: DELETE USER
            // ==========================================
            else if (userId != null) {
                int uid = Integer.parseInt(userId);
                UserDao dao = new UserDao(FactoryProvider.getFactory());
                dao.deleteUser(uid);
                
                request.getSession().setAttribute("message", "User Deleted Successfully!");
            }

            // Redirect back to dashboard
            response.sendRedirect("admin/dashboard.jsp");

        } catch (Exception e) {
            e.printStackTrace();
            // In case of error, still redirect to dashboard
            response.sendRedirect("admin/dashboard.jsp");
        }
    }
}