package com.medical.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.medical.dao.OrderDao;
import com.medical.helper.FactoryProvider;

@WebServlet("/CancelOrderServlet")
public class CancelOrderServlet extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            // Get Order ID
            int orderId = Integer.parseInt(request.getParameter("order_id"));
            
            // Call DAO to cancel and restore stock
            OrderDao dao = new OrderDao(FactoryProvider.getFactory());
            dao.cancelOrder(orderId);
            
            // Redirect back with message
            request.getSession().setAttribute("message", "Order Cancelled Successfully! Stock Restored.");
            response.sendRedirect("my_orders.jsp");
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("my_orders.jsp");
        }
    }
}