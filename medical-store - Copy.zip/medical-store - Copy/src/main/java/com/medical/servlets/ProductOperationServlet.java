package com.medical.servlets;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import com.medical.dao.CategoryDao;
import com.medical.dao.OrderDao;
import com.medical.dao.ProductDao;
import com.medical.entities.Category;
import com.medical.entities.Product;
import com.medical.helper.FactoryProvider;

@WebServlet("/ProductOperationServlet")
@MultipartConfig
public class ProductOperationServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        HttpSession session = request.getSession();
        
        try {
            String op = request.getParameter("operation");
            
            // ==========================================
            // CASE 1: ADD CATEGORY
            // ==========================================
            if(op.trim().equals("addcategory")) {
                String title = request.getParameter("catTitle");
                String description = request.getParameter("catDescription");
                
                Category category = new Category();
                category.setCategoryTitle(title);
                category.setCategoryDescription(description);
                
                CategoryDao dao = new CategoryDao(FactoryProvider.getFactory());
                dao.saveCategory(category);
                
                session.setAttribute("message", "Category Added Successfully!");
                response.sendRedirect("admin/dashboard.jsp"); 
                return;
            }
            
            // ==========================================
            // CASE 2: ADD PRODUCT
            // ==========================================
            else if(op.trim().equals("addproduct")) {
                String pName = request.getParameter("pName");
                String pDesc = request.getParameter("pDesc");
                int pPrice = Integer.parseInt(request.getParameter("pPrice"));
                int pDiscount = Integer.parseInt(request.getParameter("pDiscount"));
                int pQuantity = Integer.parseInt(request.getParameter("pQuantity"));
                int catId = Integer.parseInt(request.getParameter("catId"));
                
                Part part = request.getPart("pPic");
                String fileName = part.getSubmittedFileName();
                
                CategoryDao cdao = new CategoryDao(FactoryProvider.getFactory());
                Category category = cdao.getCategoryById(catId);
                
                Product p = new Product();
                p.setpName(pName);
                p.setpDesc(pDesc);
                p.setpPrice(pPrice);
                p.setpDiscount(pDiscount);
                p.setpQuantity(pQuantity);
                p.setpPhoto(fileName);
                p.setCategory(category);
                
                ProductDao pdao = new ProductDao(FactoryProvider.getFactory());
                boolean f = pdao.saveProduct(p);
                
                if(f) {
                    uploadFile(part, fileName, request);
                    session.setAttribute("message", "Product Added Successfully!");
                } else {
                    session.setAttribute("message", "Something went wrong adding product.");
                }
                response.sendRedirect("admin/dashboard.jsp"); 
                return;
            }

            // ==========================================
            // CASE 3: UPDATE PRODUCT
            // ==========================================
            else if(op.trim().equals("updateproduct")) {
                int pId = Integer.parseInt(request.getParameter("pId"));
                String pName = request.getParameter("pName");
                String pDesc = request.getParameter("pDesc");
                int pPrice = Integer.parseInt(request.getParameter("pPrice"));
                int pDiscount = Integer.parseInt(request.getParameter("pDiscount"));
                int pQuantity = Integer.parseInt(request.getParameter("pQuantity"));
                int catId = Integer.parseInt(request.getParameter("catId"));
                String oldPic = request.getParameter("oldPic");
                
                Part part = request.getPart("pPic");
                String newFileName = part.getSubmittedFileName();
                
                String imageToSave = oldPic;
                if(newFileName != null && !newFileName.isEmpty()) {
                    imageToSave = newFileName;
                    uploadFile(part, newFileName, request);
                }
                
                ProductDao pdao = new ProductDao(FactoryProvider.getFactory());
                boolean f = pdao.updateProduct(pId, pName, pDesc, pPrice, pDiscount, pQuantity, catId, imageToSave);
                
                if(f) {
                    session.setAttribute("message", "Product Updated Successfully!");
                } else {
                    session.setAttribute("message", "Failed to update product.");
                }
                response.sendRedirect("admin/dashboard.jsp"); 
                return;
            }

            // ==========================================
            // CASE 4: UPDATE ORDER STATUS (NEW)
            // ==========================================
            else if(op.trim().equals("update_status")) {
                int orderId = Integer.parseInt(request.getParameter("order_id"));
                String status = request.getParameter("status");

                OrderDao odao = new OrderDao(FactoryProvider.getFactory());
                boolean f = odao.updateOrderStatus(orderId, status);

                if(f) {
                    session.setAttribute("message", "Order #" + orderId + " updated to " + status);
                } else {
                    session.setAttribute("message", "Failed to update order status.");
                }
                response.sendRedirect("admin/admin_orders.jsp");
                return;
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            session.setAttribute("message", "Error: " + e.getMessage());
            response.sendRedirect("admin/dashboard.jsp");
        }
    }

    // IMPROVED HELPER METHOD TO SAVE FILE USING BUFFER
    private void uploadFile(Part part, String fileName, HttpServletRequest request) {
        try (InputStream is = part.getInputStream()) {
            String path = request.getServletContext().getRealPath("img") + File.separator + "products";
            File dir = new File(path);
            if(!dir.exists()) dir.mkdirs();

            String fullPath = path + File.separator + fileName;
            try (FileOutputStream fos = new FileOutputStream(fullPath)) {
                byte[] buffer = new byte[4096]; // 4KB buffer
                int bytesRead;
                while ((bytesRead = is.read(buffer)) != -1) {
                    fos.write(buffer, 0, bytesRead);
                }
            }
            System.out.println("File saved to: " + fullPath);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}