package com.medical.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.medical.dao.ProductDao;
import com.medical.entities.Product;
import com.medical.entities.User; 
import com.medical.helper.CartItem;
import com.medical.helper.FactoryProvider;

@WebServlet("/CartServlet")
public class CartServlet extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        try {
            // 1. GET SESSION
            HttpSession session = request.getSession();
            
            // ==========================================
            // SECURITY CHECK: IS USER LOGGED IN?
            // ==========================================
            User user = (User) session.getAttribute("current-user");
            if (user == null) {
                session.setAttribute("message", "You must login to add items to cart!");
                response.sendRedirect("login.jsp");
                return; // STOP EXECUTION HERE
            }

            // 2. GET PARAMETERS & PRODUCT DATA
            String action = request.getParameter("action");
            int pid = Integer.parseInt(request.getParameter("pid"));
            
            // We need to fetch the product from DB to check current Stock
            ProductDao dao = new ProductDao(FactoryProvider.getFactory());
            Product p = dao.getProductById(pid);
            
            List<CartItem> cart = (List<CartItem>) session.getAttribute("cart-list");
            if (cart == null) {
                cart = new ArrayList<>();
                session.setAttribute("cart-list", cart);
            }

            // ==========================================
            // ACTION: ADD (With Stock Check)
            // ==========================================
            if (action.equals("add")) {
                boolean exist = false;
                
                // Check if product already exists in cart
                for (CartItem c : cart) {
                    if (c.getProductId() == pid) {
                        
                        // --- CHECK: Does adding 1 more exceed DB stock? ---
                        if (c.getQuantity() >= p.getpQuantity()) {
                            session.setAttribute("message", "Cannot add more! Only " + p.getpQuantity() + " items left in stock.");
                            response.sendRedirect("cart.jsp");
                            return; 
                        }
                        
                        c.setQuantity(c.getQuantity() + 1);
                        exist = true;
                        session.setAttribute("message", "Quantity Increased!");
                        break;
                    }
                }
                
                // If new product, add to list
                if (!exist) {
                    // --- CHECK: Is product completely out of stock? ---
                    if (p.getpQuantity() <= 0) {
                        session.setAttribute("message", "Product is Out of Stock!");
                        response.sendRedirect("index.jsp");
                        return;
                    }

                    CartItem item = new CartItem(p.getpId(), p.getpName(), p.getpPrice(), 1);
                    cart.add(item);
                    session.setAttribute("message", "Item added to cart");
                }
                
                // ==========================================
                // NEW: CHECK FOR REDIRECT PARAMETER
                // ==========================================
                // If "Buy Now" was clicked, this param will be "cart"
                String redirectParam = request.getParameter("redirect");
                
                if("cart".equals(redirectParam)) {
                    response.sendRedirect("cart.jsp"); // Go to Checkout/Cart page
                    return;
                }

                // Normal behavior: Go back to where they came from
                String referer = request.getHeader("referer");
                response.sendRedirect(referer != null ? referer : "index.jsp");
            }
            
            // ==========================================
            // ACTION: DECREASE
            // ==========================================
            else if (action.equals("decrease")) {
                for (CartItem c : cart) {
                    if (c.getProductId() == pid) {
                        if (c.getQuantity() > 1) {
                            c.setQuantity(c.getQuantity() - 1);
                        } else {
                            // If quantity becomes 0, remove it
                            cart.remove(c); 
                        }
                        break;
                    }
                }
                response.sendRedirect("cart.jsp");
            }

            // ==========================================
            // ACTION: DELETE
            // ==========================================
            else if (action.equals("delete")) {
                // Java 8 style removal
                cart.removeIf(c -> c.getProductId() == pid);
                session.setAttribute("message", "Item removed from cart");
                response.sendRedirect("cart.jsp");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("index.jsp");
        }
    }
}