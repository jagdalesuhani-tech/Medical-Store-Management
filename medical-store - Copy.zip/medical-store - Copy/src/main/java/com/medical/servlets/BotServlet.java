package com.medical.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/BotServlet")
public class BotServlet extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        // 1. Get User's Message
        String query = request.getParameter("query");
        
        // 2. Get (or Create) Chat History from Session
        HttpSession session = request.getSession();
        List<String> chatHistory = (List<String>) session.getAttribute("chat-history");
        
        if(chatHistory == null) {
            chatHistory = new ArrayList<>();
        }
        
        // 3. Add User Message to History
        if(query != null && !query.trim().isEmpty()) {
            chatHistory.add("User: " + query);
            
            // 4. Generate Bot Response (Simple Logic)
            String botReply = "Bot: I don't understand.";
            query = query.toLowerCase();
            
            if(query.contains("hello") || query.contains("hi")) {
                botReply = "Bot: Hello! How can I help you today?";
            } else if(query.contains("fever")) {
                botReply = "Bot: You can take Paracetamol 500mg.";
            } else if(query.contains("headache")) {
                botReply = "Bot: Try Disprin or rest for a while.";
            } else if(query.contains("cold")) {
                botReply = "Bot: Drink warm water and take Vitamin C.";
            }
            
            chatHistory.add(botReply);
        }
        
        // 5. Save back to session and Redirect
        session.setAttribute("chat-history", chatHistory);
        response.sendRedirect("index.jsp#chat-box"); // Reload page and jump to chat
    }
}