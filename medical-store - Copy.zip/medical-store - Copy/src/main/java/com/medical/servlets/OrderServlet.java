package com.medical.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.medical.dao.ProductDao;
import com.medical.entities.Order;
import com.medical.entities.OrderDetail;
import com.medical.entities.Payment;
import com.medical.entities.Product;
import com.medical.entities.User;
import com.medical.helper.CartItem;
import com.medical.helper.EmailHelper; // Import Email Helper
import com.medical.helper.FactoryProvider;

@WebServlet("/OrderServlet")
public class OrderServlet extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            HttpSession session = request.getSession();
            User user = (User) session.getAttribute("current-user");
            List<CartItem> cart = (List<CartItem>) session.getAttribute("cart-list");
            
            if(user == null || cart == null || cart.isEmpty()) {
                response.sendRedirect("index.jsp");
                return;
            }

            // 1. CALCULATE TOTAL
            int totalAmount = 0;
            for(CartItem i : cart) {
                totalAmount += i.getTotalPrice();
            }

            // 2. PREPARE PAYMENT DATA
            String paymentMode = request.getParameter("payment_mode"); 
            if(paymentMode == null) paymentMode = "COD";

            String paymentStatus = "Pending";
            String txnId = request.getParameter("transaction_id");
            if(txnId == null) txnId = "N/A";
            
            if(!paymentMode.equals("COD")) {
                paymentStatus = "Success"; 
            }

            // 3. OPEN HIBERNATE SESSION & SAVE ORDER
            Session s = FactoryProvider.getFactory().openSession();
            Transaction tx = s.beginTransaction();

            Order order = new Order(user, "Placed", new Date(), totalAmount);
            Payment payment = new Payment(order, paymentMode, paymentStatus, txnId);
            order.setPayment(payment); 

            List<OrderDetail> details = new ArrayList<>();
            
            for(CartItem item : cart) {
                Product p = (Product) s.get(Product.class, item.getProductId());
                OrderDetail detail = new OrderDetail(order, p, item.getQuantity(), item.getPrice());
                details.add(detail);
                
                // DECREASE STOCK
                int newQty = p.getpQuantity() - item.getQuantity();
                if(newQty < 0) newQty = 0;
                p.setpQuantity(newQty);
                s.update(p); 
            }
            
            order.setOrderDetails(details); 
            s.save(order);
            tx.commit();
            s.close();

            // =================================================================
            // 4. SEND EMAIL (Running in Background)
            // =================================================================
            final String userEmail = user.getUserEmail();
            final String userName = user.getUserName();
            final int orderId = order.getOrderId();
            final String pMode = paymentMode;
            final int grandTotal = totalAmount;
            final List<CartItem> emailCart = new ArrayList<>(cart); // Copy cart for email thread

            // Start a new thread so the user doesn't wait for the email to send
            new Thread(() -> {
                
                StringBuilder html = new StringBuilder();
                html.append("<html><body style='font-family: sans-serif; padding: 20px; border:1px solid #ddd;'>");
                html.append("<h2 style='color:#007bff;'>Order Confirmed!</h2>");
                html.append("<p>Dear " + userName + ",</p>");
                html.append("<p>Thank you for shopping with MediCare. Your order has been placed successfully.</p>");
                
                html.append("<h3>Order ID: #" + orderId + "</h3>");
                html.append("<table style='width:100%; border-collapse: collapse; border:1px solid #eee;'>");
                html.append("<tr style='background:#f8f9fa; text-align:left;'><th>Product</th><th>Qty</th><th>Price</th></tr>");
                
                for(CartItem c : emailCart) {
                    html.append("<tr>");
                    html.append("<td style='border:1px solid #eee; padding:8px;'>" + c.getProductName() + "</td>");
                    html.append("<td style='border:1px solid #eee; padding:8px;'>" + c.getQuantity() + "</td>");
                    html.append("<td style='border:1px solid #eee; padding:8px;'>" + c.getTotalPrice() + "</td>");
                    html.append("</tr>");
                }
                html.append("</table>");
                
                html.append("<h3>Total Amount: &#8377;" + grandTotal + "</h3>");
                html.append("<p>Payment Mode: " + pMode + "</p>");
                html.append("<hr><p style='color:#777; font-size:12px;'>This is an automated email.</p>");
                html.append("</body></html>");

                // Send the email
                EmailHelper.sendEmail(userEmail, "Order Confirmation - MediCare", html.toString());
                
            }).start();

            // 5. CLEAR CART & REDIRECT
            session.removeAttribute("cart-list");
            // Pass order object to success page to show ID
            session.setAttribute("order", order); 
            response.sendRedirect("order_success.jsp");

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("index.jsp");
        }
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}