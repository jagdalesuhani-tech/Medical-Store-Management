package com.medical.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.medical.dao.UserDao;
import com.medical.entities.User;
import com.medical.helper.FactoryProvider;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try {
            // 1. Fetch data from JSP form
            String userName = request.getParameter("user_name");
            String userEmail = request.getParameter("user_email");
            String userPass = request.getParameter("user_pass");
            String userPhone = request.getParameter("user_phone");
            String userAddress = request.getParameter("user_address");

            // 2. Create User Object
            // Default type is "normal". Admin type is set manually in DB.
            User user = new User(userName, userEmail, userPass, userPhone, userAddress, "normal");

            // 3. Save using DAO
            UserDao dao = new UserDao(FactoryProvider.getFactory());
            boolean flag = dao.saveUser(user);

            // 4. Send response
            HttpSession session = request.getSession();
            if (flag) {
                session.setAttribute("message", "Registration Successful! Please Login.");
                response.sendRedirect("login.jsp");
            } else {
                session.setAttribute("message", "Something went wrong on server!");
                response.sendRedirect("register.jsp");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}