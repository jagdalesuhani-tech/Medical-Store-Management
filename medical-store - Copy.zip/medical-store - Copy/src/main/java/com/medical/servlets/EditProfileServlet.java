package com.medical.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.medical.dao.UserDao;
import com.medical.entities.User;
import com.medical.helper.FactoryProvider;

@WebServlet("/EditProfileServlet")
public class EditProfileServlet extends HttpServlet {
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        try {
            // 1. Get Data from Form
            String userName = request.getParameter("user_name");
            String userPhone = request.getParameter("user_phone");
            String userAddress = request.getParameter("user_address");
            
            // 2. Get Current User from Session
            HttpSession session = request.getSession();
            User user = (User) session.getAttribute("current-user");
            
            // 3. Update the User Object
            user.setUserName(userName);
            user.setUserPhone(userPhone);
            user.setUserAddress(userAddress);
            
            // 4. Update Database
            UserDao dao = new UserDao(FactoryProvider.getFactory());
            dao.updateUser(user);
            
            // 5. Update Session (Important!)
            session.setAttribute("current-user", user);
            session.setAttribute("message", "Profile Updated Successfully!");
            
            response.sendRedirect("profile.jsp");
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp");
        }
    }
}