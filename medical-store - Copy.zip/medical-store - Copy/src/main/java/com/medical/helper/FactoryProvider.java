package com.medical.helper;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class FactoryProvider {
    private static SessionFactory factory;

    // This method returns the database connection object
    public static SessionFactory getFactory() {
        try {
            if (factory == null) {
                // First time setup: loads hibernate.cfg.xml
                factory = new Configuration()
                        .configure("hibernate.cfg.xml")
                        .buildSessionFactory();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return factory;
    }
}