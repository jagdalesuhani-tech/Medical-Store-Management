package com.medical.helper;

import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;

public class EmailHelper {
    
    public static boolean sendEmail(String to, String subject, String body) {
        boolean isSent = false;

        // ====================================================
        // CONFIGURATION
        // ====================================================
        final String from = "omkardhanavade2005@gmail.com"; 
        // I have kept your password here, but for security, ensure no spaces are around it
        final String password = "xvtdbmfrozsggyvz"; 
        // ====================================================

        // 1. Setup Mail Server Properties
        Properties props = new Properties();
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        
        // --- CRITICAL FIXES ADDED HERE ---
        // Fix 1: Force Java to use TLS 1.2 (Required by Gmail)
        props.put("mail.smtp.ssl.protocols", "TLSv1.2");
        
        // Fix 2: Tell Java to trust the Gmail server (Fixes PKIX/Antivirus errors)
        props.put("mail.smtp.ssl.trust", "smtp.gmail.com");
        // ---------------------------------

        // 2. Get Session
        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(from, password);
            }
        });

        // 3. Compose and Send
        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(from));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
            message.setSubject(subject);
            message.setContent(body, "text/html"); // Allows HTML design

            Transport.send(message);
            isSent = true;
            System.out.println("Email sent successfully to: " + to);
            
        } catch (MessagingException e) {
            e.printStackTrace();
        }
        
        return isSent;
    }
}