package com.medical.helper;

import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;

public class TestEmail {

    public static void main(String[] args) {
        
        System.out.println("1. Starting Email Test...");

        final String from = "omkardhanavade@gmail.com";  
        final String password = "xvtdbmfrozsggyvz"; 

        // Properties
        Properties props = new Properties();
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        
        // --- FIX 1: TLS VERSION (Keep this) ---
        props.put("mail.smtp.ssl.protocols", "TLSv1.2");
        
        // --- FIX 2: TRUST GMAIL (New Fix) ---
        props.put("mail.smtp.ssl.trust", "smtp.gmail.com");
        // ------------------------------------

        props.put("mail.debug", "true");

        Session session = Session.getInstance(props, new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(from, password);
            }
        });

        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(from));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(from));
            message.setSubject("Test Email (Trust Fixed)");
            message.setText("If you get this, the PKIX error is solved!");

            System.out.println("2. Attempting to send...");
            Transport.send(message);
            System.out.println("3. SUCCESS! Email sent.");

        } catch (Exception e) {
            System.out.println("4. FAILED!");
            e.printStackTrace();
        }
    }
}