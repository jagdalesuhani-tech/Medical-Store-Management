package com.medical.dao;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.medical.entities.Category; // Added Import
import com.medical.entities.Product;

public class ProductDao {
    private SessionFactory factory;

    public ProductDao(SessionFactory factory) {
        this.factory = factory;
    }

    // 1. SAVE PRODUCT (Create)
    public boolean saveProduct(Product product) {
        boolean f = false;
        try {
            Session session = this.factory.openSession();
            Transaction tx = session.beginTransaction();
            session.save(product);
            tx.commit();
            session.close();
            f = true;
        } catch (Exception e) {
            e.printStackTrace();
            f = false;
        }
        return f;
    }

    // 2. GET ALL PRODUCTS (Read - for Dashboard)
    public List<Product> getAllProducts() {
        Session s = this.factory.openSession();
        Query query = s.createQuery("from Product");
        List<Product> list = query.list();
        s.close();
        return list;
    }

    // 3. DELETE PRODUCT (Delete - for DeleteServlet)
    public void deleteProduct(int pid) {
        Session s = this.factory.openSession();
        Transaction tx = s.beginTransaction();
        
        // Delete query using pId (matches Product.java)
        Query q = s.createQuery("delete from Product as p where p.pId =: id");
        q.setParameter("id", pid);
        q.executeUpdate();
        
        tx.commit();
        s.close();
    }

    // 4. GET SINGLE PRODUCT BY ID (For the Edit Page)
    public Product getProductById(int pid) {
        Product p = null;
        try {
            Session session = this.factory.openSession();
            p = session.get(Product.class, pid);
            session.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return p;
    }

    // 5. UPDATE PRODUCT (Original - Takes Object)
    public void updateProduct(Product p) {
        Session session = this.factory.openSession();
        Transaction tx = session.beginTransaction();
        session.update(p);
        tx.commit();
        session.close();
    }

    // =========================================================
    // 6. UPDATE PRODUCT (Detailed - THIS WAS MISSING)
    // =========================================================
    public boolean updateProduct(int pid, String pName, String pDesc, int pPrice, int pDiscount, int pQuantity, int catId, String pPic) {
        boolean f = false;
        try {
            Session session = this.factory.openSession();
            Transaction tx = session.beginTransaction();
            
            // A. Load existing product
            Product p = session.get(Product.class, pid);
            
            // B. Load new Category
            Category c = session.get(Category.class, catId);
            
            // C. Update details
            p.setpName(pName);
            p.setpDesc(pDesc);
            p.setpPrice(pPrice);
            p.setpDiscount(pDiscount);
            p.setpQuantity(pQuantity);
            p.setpPhoto(pPic);
            p.setCategory(c);
            
            // D. Save to DB
            session.update(p);
            tx.commit();
            session.close();
            f = true;
            
        } catch (Exception e) {
            e.printStackTrace();
            f = false;
        }
        return f;
    }
}