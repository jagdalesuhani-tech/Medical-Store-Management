package com.medical.dao;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction; 
import org.hibernate.query.Query;
import com.medical.entities.Order;
import com.medical.entities.OrderDetail; 
import com.medical.entities.Product;      

public class OrderDao {
    
    private SessionFactory factory;

    public OrderDao(SessionFactory factory) {
        this.factory = factory;
    }

    // 1. Get all orders for a specific user (Client Side)
    public List<Order> getOrdersByUserId(int userId) {
        Session s = this.factory.openSession();
        Query q = s.createQuery("from Order as o where o.user.userId =: uid order by o.orderId desc");
        q.setParameter("uid", userId);
        List<Order> list = q.list();
        // Fix for Lazy Loading: initialize the collection while session is open
        for(Order o : list) {
            o.getOrderDetails().size();
        }
        s.close();
        return list;
    }

    // 2. Get ALL orders (Admin Side)
    public List<Order> getAllOrders() {
        Session s = this.factory.openSession();
        Query q = s.createQuery("from Order as o order by o.orderId desc");
        List<Order> list = q.list();
        
        // Touch collection to fetch data before session close
        for(Order o : list) {
            o.getOrderDetails().size(); 
        }

        s.close();
        return list;
    }

    // 3. CANCEL ORDER & RESTORE STOCK (User Side)
    public boolean cancelOrder(int orderId) {
        boolean f = false;
        Session s = this.factory.openSession();
        Transaction tx = s.beginTransaction();

        try {
            Order order = s.get(Order.class, orderId);

            if (order != null && !order.getOrderStatus().equals("Cancelled")) {
                // Restore stock logic
                for (OrderDetail detail : order.getOrderDetails()) {
                    Product p = detail.getProduct();
                    int restoredQty = p.getpQuantity() + detail.getQuantity();
                    p.setpQuantity(restoredQty);
                    s.update(p);
                }
                
                order.setOrderStatus("Cancelled");
                s.update(order);
                tx.commit();
                f = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
            if (tx != null) tx.rollback();
        } finally {
            s.close();
        }
        return f;
    }

    // 4. UPDATE ORDER STATUS (ADMIN SIDE) - Refined for Servlet Response
    public boolean updateOrderStatus(int orderId, String status) {
        boolean f = false;
        Session s = this.factory.openSession();
        Transaction tx = s.beginTransaction();
        
        try {
            Order o = s.get(Order.class, orderId);
            if (o != null) {
                o.setOrderStatus(status);
                s.update(o);
                tx.commit();
                f = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
            if (tx != null) tx.rollback();
        } finally {
            s.close();
        }
        return f;
    }
}