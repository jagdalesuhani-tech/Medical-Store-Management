package com.medical.dao;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import com.medical.entities.User;

public class UserDao {
    private SessionFactory factory;

    public UserDao(SessionFactory factory) {
        this.factory = factory;
    }

    // METHOD 1: Save a user to Database (For Registration)
    public boolean saveUser(User user) {
        boolean f = false;
        try {
            Session session = this.factory.openSession();
            Transaction tx = session.beginTransaction();
            session.save(user); 
            tx.commit();
            session.close();
            f = true;
        } catch (Exception e) {
            e.printStackTrace();
            f = false;
        }
        return f;
    }

    // METHOD 2: Get user by Email & Password (For Login)
    public User getUserByEmailAndPassword(String email, String password) {
        User user = null;
        try {
            Session session = this.factory.openSession();
            String query = "from User where userEmail =: e and userPassword =: p";
            Query q = session.createQuery(query);
            q.setParameter("e", email);
            q.setParameter("p", password);
            user = (User) q.uniqueResult(); 
            session.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return user;
    }

    // METHOD 3: Get ALL Users (For Admin Dashboard)
    public List<User> getAllUsers() {
        List<User> list = null;
        try {
            Session s = this.factory.openSession();
            Query q = s.createQuery("from User");
            list = q.list();
            s.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // METHOD 4: Delete User by ID
    public void deleteUser(int userId) {
        try {
            Session s = this.factory.openSession();
            Transaction tx = s.beginTransaction();
            User user = s.get(User.class, userId);
            s.delete(user);
            tx.commit();
            s.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ==========================================
    // METHOD 5: Update User (NEW - For Edit Profile)
    // ==========================================
    public void updateUser(User user) {
        Session s = this.factory.openSession();
        Transaction tx = s.beginTransaction();
        
        try {
            s.update(user); // This saves the changes to the DB
            tx.commit();
        } catch (Exception e) {
            e.printStackTrace();
            tx.rollback();
        } finally {
            s.close();
        }
    }
}