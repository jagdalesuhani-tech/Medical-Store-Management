<%@ page language="java" contentType="text/html; charset=ISO-8859-1" pageEncoding="ISO-8859-1"%>
<%@ page import="com.medical.helper.FactoryProvider" %>
<%@ page import="com.medical.helper.CartItem" %>
<%@ page import="com.medical.dao.ProductDao" %>
<%@ page import="com.medical.entities.Product" %>
<%@ page import="java.util.List" %>

<!DOCTYPE html>
<html>
<head>
    <title>My Cart - MediCare</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/style.css">
    
    <style>
        .cart-container { background-color: #f1f3f6; min-height: 100vh; padding-bottom: 50px; }
        .cart-header { font-size: 18px; font-weight: 600; padding: 15px; background: #fff; border-bottom: 1px solid #eee; }
        .cart-item { background: #fff; padding: 20px; border-bottom: 1px solid #eee; display: flex; align-items: center; }
        .cart-item:last-child { border-bottom: none; }
        
        .cart-img-container {
            width: 120px;
            height: 100px;
            text-align: center;
            margin-right: 20px;
        }
        .cart-product-img {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
        }

        .qty-btn {
            border-radius: 50%;
            width: 30px;
            height: 30px;
            line-height: 28px;
            text-align: center;
            font-weight: bold;
            border: 1px solid #c2c2c2;
            background: #fff;
            color: #333;
            display: inline-block;
        }
        .qty-btn:hover { background: #f0f0f0; text-decoration: none; color: #333; }
        
        .bill-details { background: #fff; position: sticky; top: 90px; border: 1px solid #e0e0e0; }
        .bill-header { color: #878787; font-weight: 600; font-size: 16px; padding: 15px 24px; border-bottom: 1px solid #f0f0f0; }
        .bill-row { display: flex; justify-content: space-between; padding: 10px 24px; font-size: 15px; }
        .total-row { border-top: 1px dashed #e0e0e0; font-weight: 700; font-size: 18px; padding-top: 15px; margin-top: 10px; }
        
        .btn-pay {
            background-color: #fb641b; 
            color: white;
            font-size: 16px;
            font-weight: 600;
            padding: 12px;
            text-transform: uppercase;
            box-shadow: 0 2px 4px rgba(0,0,0,.2);
        }
        .btn-pay:hover { background-color: #f4511e; color: white; }
    </style>
</head>
<body class="cart-container">

    <%@ include file="components/navbar.jsp" %>

    <div class="container mt-4">
        
        <%
            String message = (String) session.getAttribute("message");
            if(message != null) {
        %>
            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                <strong>Notice:</strong> <%= message %>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <%
                // Remove message after showing it so it doesn't stick
                session.removeAttribute("message");
            }
        %>
        <div class="row">
            
            <%
                List<CartItem> list = (List<CartItem>) session.getAttribute("cart-list");
                int grandTotal = 0;
                int totalItems = 0;
                ProductDao pDao = new ProductDao(FactoryProvider.getFactory());
                
                if (list != null && list.size() > 0) {
                    for(CartItem item : list) {
                        grandTotal += item.getTotalPrice();
                        totalItems += item.getQuantity();
                    }
            %>

            <div class="col-md-8">
                <div class="card shadow-sm">
                    <div class="cart-header">
                        My Cart (<%= list.size() %>)
                    </div>

                    <% 
                        for (CartItem item : list) { 
                            Product p = pDao.getProductById(item.getProductId());
                            String imageName = (p != null) ? p.getpPhoto() : "default.png";
                    %>
                    <div class="cart-item">
                        <div class="cart-img-container">
                            <img src="img/products/<%= imageName %>" class="cart-product-img" alt="Product Image">
                        </div>

                        <div style="flex-grow: 1;">
                            <h5 style="font-size: 16px; margin-bottom: 5px;"><%= item.getProductName() %></h5>
                            <span class="text-muted small">Seller: MediCare Inc.</span>
                            
                            <div class="mt-2">
                                <span style="font-size: 18px; font-weight: 600;">&#8377;<%= item.getPrice() %></span> 
                            </div>
                        </div>

                        <div class="text-right" style="min-width: 120px;">
                            
                            <div class="mb-3">
                                <a href="CartServlet?action=decrease&pid=<%= item.getProductId() %>" class="qty-btn" <%= (item.getQuantity() == 1) ? "style='opacity:0.5; pointer-events:none;'" : "" %>>-</a>
                                <span class="mx-2 border px-3 py-1 bg-light"><%= item.getQuantity() %></span>
                                <a href="CartServlet?action=add&pid=<%= item.getProductId() %>" class="qty-btn">+</a>
                            </div>

                            <a href="CartServlet?action=delete&pid=<%= item.getProductId() %>" class="text-danger font-weight-bold small">REMOVE</a>
                        </div>
                    </div>
                    <% } %>
                    
                </div>
            </div>

            <div class="col-md-4">
                <div class="card shadow-sm bill-details">
                    <div class="bill-header">PRICE DETAILS</div>
                    
                    <div class="bill-row mt-3">
                        <span>Price (<%= totalItems %> items)</span>
                        <span>&#8377;<%= grandTotal %></span>
                    </div>
                    
                    <div class="bill-row">
                        <span>Delivery Charges</span>
                        <span class="text-success">FREE</span>
                    </div>
                    
                    <div class="bill-row total-row">
                        <span>Total Payable</span>
                        <span>&#8377;<%= grandTotal %></span>
                    </div>
                    
                    <div class="p-3 mt-2" style="border-top: 1px solid #f0f0f0;">
                        <a href="checkout.jsp" class="btn btn-pay btn-block text-white">Proceed to Pay</a>
                    </div>
                </div>
            </div>

            <% 
                } else { 
            %>
                <div class="col-md-12 text-center mt-5">
                    <div class="card p-5 shadow-sm">
                        <i class="fa fa-shopping-basket fa-5x text-muted mb-3"></i>
                        <h3>Your Cart is Empty!</h3>
                        <p class="text-muted">Add medicines to your cart now.</p>
                        <a href="index.jsp" class="btn btn-primary mt-3">Shop Now</a>
                    </div>
                </div>
            <% } %>

        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

</body>
</html>