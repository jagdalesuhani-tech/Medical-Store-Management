<%@ page language="java" contentType="text/html; charset=ISO-8859-1" pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="ISO-8859-1">
    <title>Login - MediCare</title>
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
    <style>
        /* 1. Import Poppins Font */
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap');

        /* 2. Background Theme */
        body {
            font-family: 'Poppins', sans-serif;
            background-image: url('img/body-bg.jpg'); /* Ensure you have this image */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        /* 3. The Glass Card */
        .login-card {
            background: rgba(255, 255, 255, 0.92); /* Glass Effect */
            padding: 40px 30px;
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 400px;
            border: 1px solid #ffe3e8; /* Pink Border to match theme */
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        /* Top Colored Bar */
        .login-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 5px;
            background: linear-gradient(90deg, #007bff, #ff4081);
        }

        /* Logo Icon Circle */
        .icon-circle {
            width: 80px;
            height: 80px;
            background: #e3f2fd;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px auto;
            color: #007bff;
            font-size: 35px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        h3 {
            color: #333;
            font-weight: 700;
            margin-bottom: 5px;
        }
        
        p.subtitle {
            color: #777;
            font-size: 14px;
            margin-bottom: 30px;
        }

        /* Input Fields styling */
        .form-group {
            position: relative;
            margin-bottom: 20px;
            text-align: left;
        }

        .form-group label {
            font-size: 13px;
            font-weight: 600;
            color: #555;
            margin-bottom: 5px;
            display: block;
        }

        .input-with-icon {
            position: relative;
        }

        .input-with-icon i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #aaa;
        }

        .form-control {
            padding-left: 45px; /* Space for icon */
            height: 45px;
            border-radius: 50px; /* Pill shape */
            border: 1px solid #e0e0e0;
            font-size: 14px;
            background: #fdfdfd;
        }

        .form-control:focus {
            border-color: #007bff;
            box-shadow: 0 0 0 3px rgba(0,123,255,0.1);
        }

        /* Button Styling */
        .btn-login {
            background: linear-gradient(135deg, #007bff, #0062cc);
            border: none;
            width: 100%;
            height: 45px;
            border-radius: 50px;
            color: white;
            font-weight: 600;
            font-size: 16px;
            margin-top: 10px;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 5px 15px rgba(0,123,255,0.3);
        }

        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(0,123,255,0.4);
        }

        /* Links */
        .register-link {
            margin-top: 20px;
            display: block;
            font-size: 14px;
            color: #666;
        }
        .register-link a {
            color: #ff4081; /* Pink link */
            font-weight: 600;
            text-decoration: none;
        }
        .register-link a:hover { text-decoration: underline; }

        /* Error Message Box */
        .alert-custom {
            font-size: 13px;
            border-radius: 10px;
            padding: 10px;
        }
    </style>
</head>
<body>

    <div class="login-card">
        <div class="icon-circle">
            <i class="fa fa-user-md"></i>
        </div>

        <h3>Welcome Back</h3>
        <p class="subtitle">Login to manage your medical store</p>

        <% 
            String message = (String)session.getAttribute("message");
            if(message != null){
        %>
            <div class="alert alert-danger alert-custom" role="alert">
                <i class="fa fa-exclamation-circle mr-1"></i> <%= message %>
            </div>
        <% 
            session.removeAttribute("message"); 
            }
        %>

        <form action="LoginServlet" method="post">
            
            <div class="form-group">
                <label>Email Address</label>
                <div class="input-with-icon">
                    <i class="fa fa-envelope"></i>
                    <input type="email" name="email" class="form-control" placeholder="example@gmail.com" required>
                </div>
            </div>

            <div class="form-group">
                <label>Password</label>
                <div class="input-with-icon">
                    <i class="fa fa-lock"></i>
                    <input type="password" name="password" class="form-control" placeholder="Enter your password" required>
                </div>
            </div>

            <button type="submit" class="btn-login">Login Securely</button>
        </form>

        <div class="register-link">
            New to MediCare? <a href="register.jsp">Create Account</a>
        </div>
    </div>

</body>
</html>