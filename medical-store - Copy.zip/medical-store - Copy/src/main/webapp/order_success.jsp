<%@ page language="java" contentType="text/html; charset=ISO-8859-1" pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
    <title>Order Placed - MediCare</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/style.css">
    
    <style>
        body { background-color: #f1f3f6; }
        .success-card {
            background: white;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
            padding: 40px;
            margin-top: 50px;
            text-align: center;
        }
        .check-icon {
            color: #28a745;
            font-size: 80px;
            margin-bottom: 20px;
        }
        .order-id {
            background: #f8f9fa;
            padding: 10px 20px;
            border-radius: 5px;
            display: inline-block;
            margin: 20px 0;
            font-weight: bold;
            color: #555;
            border: 1px dashed #ccc;
        }
    </style>
</head>
<body>

    <%@ include file="components/navbar.jsp" %>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                
                <div class="success-card">
                    <i class="fa fa-check-circle check-icon"></i>
                    
                    <h2 class="text-success">Thank You!</h2>
                    <h4 class="mb-3">Your Order has been placed successfully.</h4>
                    
                    <p class="text-muted">You will receive a confirmation email shortly with the expected delivery date.</p>
                    
                    <div class="order-id">
                        Order ID: #ORD<%= (int)(Math.random() * 1000000) %>
                    </div>
                    
                    <br>
                    
                    <a href="index.jsp" class="btn btn-primary btn-lg mt-3 custom-bg">
                        <i class="fa fa-home"></i> Continue Shopping
                    </a>
                </div>

            </div>
        </div>
    </div>

</body>
</html>