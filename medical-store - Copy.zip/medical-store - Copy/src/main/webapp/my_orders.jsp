<%@ page language="java" contentType="text/html; charset=ISO-8859-1" pageEncoding="ISO-8859-1"%>
<%@ page import="com.medical.entities.*" %>
<%@ page import="com.medical.dao.OrderDao" %>
<%@ page import="com.medical.helper.FactoryProvider" %>
<%@ page import="java.util.List" %>

<%
    User user = (User) session.getAttribute("current-user");
    if(user == null) {
        response.sendRedirect("login.jsp");
        return;
    }
%>

<!DOCTYPE html>
<html>
<head>
    <title>My Orders - MediCare</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body style="background: #f1f3f6;">

    <%@ include file="components/navbar.jsp" %>

    <div class="container mt-4">
        
        <% 
            String msg = (String) session.getAttribute("message");
            if(msg != null) {
        %>
            <div class="alert alert-success alert-dismissible fade show">
                <strong>Success!</strong> <%= msg %>
                <button type="button" class="close" data-dismiss="alert">&times;</button>
            </div>
        <% 
            session.removeAttribute("message");
            } 
        %>

        <div class="card shadow-sm">
            <div class="card-header bg-white">
                <h4>My Order History</h4>
            </div>
            <div class="card-body">
                <table class="table table-hover">
                    <thead class="thead-light">
                        <tr>
                            <th>Order ID</th>
                            <th>Date</th>
                            <th>Total Amount</th>
                            <th>Payment Mode</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <%
                            OrderDao oDao = new OrderDao(FactoryProvider.getFactory());
                            List<Order> orders = oDao.getOrdersByUserId(user.getUserId());
                            
                            for(Order o : orders) {
                        %>
                        <tr>
                            <td>#<%= o.getOrderId() %></td>
                            <td><%= o.getOrderDate() %></td>
                            
                            <td>&#8377; <%= o.getTotalAmount() %></td>
                            
                            <td><%= o.getPayment().getPaymentMode() %></td>
                            <td>
                                <% 
                                    String status = o.getOrderStatus();
                                    String badgeClass = "badge-secondary";

                                    if(status.equals("Placed")) badgeClass = "badge-primary";
                                    else if(status.equals("Confirmed")) badgeClass = "badge-info";
                                    else if(status.equals("Shipped")) badgeClass = "badge-warning";
                                    else if(status.equals("Delivered")) badgeClass = "badge-success";
                                    else if(status.equals("Cancelled")) badgeClass = "badge-danger";
                                %>
                                <span class="badge <%= badgeClass %> px-3 py-2"><%= status %></span>
                            </td>
                            <td>
                                <% if(status.equals("Placed") || status.equals("Confirmed")) { %>
                                    
                                    <button onclick="cancelOrder(<%= o.getOrderId() %>)" class="btn btn-sm btn-outline-danger">
                                        <i class="fa fa-times"></i> Cancel
                                    </button>
                                    
                                <% } else if(status.equals("Cancelled")) { %>
                                    <span class="text-danger small font-weight-bold">Cancelled</span>
                                <% } else { %>
                                    <span class="text-muted small">Cannot Cancel</span>
                                <% } %>
                            </td>
                        </tr>
                        <% } %>
                        
                        <% if(orders.isEmpty()) { %>
                            <tr><td colspan="6" class="text-center">No orders found.</td></tr>
                        <% } %>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

    <script>
        function cancelOrder(id) {
            let check = confirm("Are you sure you want to cancel Order #" + id + "? The items will be returned to stock.");
            if(check) {
                window.location = "CancelOrderServlet?order_id=" + id;
            }
        }
    </script>

</body>
</html>