<%@ page language="java" contentType="text/html; charset=ISO-8859-1" pageEncoding="ISO-8859-1"%>
<%@ page import="com.medical.entities.User" %>
<%@ page import="com.medical.dao.CategoryDao" %>
<%@ page import="com.medical.dao.ProductDao" %>
<%@ page import="com.medical.dao.UserDao" %>
<%@ page import="com.medical.entities.Category" %>
<%@ page import="com.medical.entities.Product" %>
<%@ page import="com.medical.helper.FactoryProvider" %>
<%@ page import="java.util.List" %>
<%@ page import="com.medical.helper.Helper" %>

<%
    User user = (User) session.getAttribute("current-user");
    if (user == null) {
        session.setAttribute("message", "You are not logged in! Login first.");
        response.sendRedirect("login.jsp");
        return;
    } else {
        if (user.getUserType().equals("normal")) {
            session.setAttribute("message", "You are not Admin! Do not access this page.");
            response.sendRedirect("login.jsp");
            return;
        }
    }
%>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard - MediCare</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/style.css">
    
    <style>
        .admin-card {
            border: 1px solid #e0e0e0;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            border-radius: 10px;
            background: white;
        }
        .admin-card:hover {
            background: #fdfdfd;
            cursor: pointer;
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
            transform: translateY(-5px);
            transition: 0.3s;
        }
        .card-icon-container {
            height: 80px;
            width: 80px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto;
        }
    </style>
</head>
<body style="background-color: #f4f7f6;">

    <%@ include file="components/navbar.jsp" %>

    <div class="container admin mt-4">
        
        <div class="container-fluid">
            <%@ include file="components/message.jsp" %>
        </div>

        <div class="row mt-3">
            
            <div class="col-md-4">
                <div class="card admin-card text-center" data-toggle="modal" data-target="#users-modal">
                    <div class="card-body">
                        <div class="card-icon-container bg-light mb-3">
                            <i class="fa fa-users fa-3x text-primary"></i>
                        </div>
                        <%
                            UserDao udao = new UserDao(FactoryProvider.getFactory());
                            List<User> userList = udao.getAllUsers();
                        %>
                        <h2 class="font-weight-bold"><%= userList.size() %></h2> 
                        <h6 class="text-uppercase text-muted">Users</h6>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card admin-card text-center" data-toggle="modal" data-target="#categories-modal">
                    <div class="card-body">
                        <div class="card-icon-container bg-light mb-3">
                            <i class="fa fa-list-alt fa-3x text-warning"></i>
                        </div>
                        <%
                            CategoryDao catDao = new CategoryDao(FactoryProvider.getFactory());
                            List<Category> clist = catDao.getCategories();
                        %>
                        <h2 class="font-weight-bold"><%= clist.size() %></h2>
                        <h6 class="text-uppercase text-muted">Categories</h6>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card admin-card text-center" data-toggle="modal" data-target="#products-modal">
                    <div class="card-body">
                        <div class="card-icon-container bg-light mb-3">
                            <i class="fa fa-medkit fa-3x text-danger"></i>
                        </div>
                        <%
                            ProductDao pdao = new ProductDao(FactoryProvider.getFactory());
                            List<Product> plist = pdao.getAllProducts();
                        %>
                        <h2 class="font-weight-bold"><%= plist.size() %></h2>
                        <h6 class="text-uppercase text-muted">Medicines</h6>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mt-4">
            <div class="col-md-6">
                <div class="card admin-card" data-toggle="modal" data-target="#add-category-modal">
                    <div class="card-body text-center p-4">
                        <i class="fa fa-plus-circle fa-4x text-success mb-3"></i>
                        <h5 class="text-uppercase text-muted">Add Category</h5>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card admin-card" data-toggle="modal" data-target="#add-product-modal">
                    <div class="card-body text-center p-4">
                        <i class="fa fa-plus-circle fa-4x text-warning mb-3"></i>
                        <h5 class="text-uppercase text-muted">Add Product</h5>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="row mt-4 mb-5">
            <div class="col-md-12">
                <div class="card shadow-sm">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">Manage Products</h5>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead class="thead-light">
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Price</th>
                                        <th>Stock</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <% for (Product p : plist) { %>
                                    <tr>
                                        <td><%= p.getpId() %></td>
                                        <td><%= p.getpName() %></td>
                                        <td>&#8377; <%= p.getpPrice() %></td>
                                        <td>
                                            <% if(p.getpQuantity() < 5) { %>
                                                <span class="badge badge-danger">Low: <%= p.getpQuantity() %></span>
                                            <% } else { %>
                                                <%= p.getpQuantity() %>
                                            <% } %>
                                        </td>
                                        <td>
                                            <button class="btn btn-sm btn-outline-primary"><i class="fa fa-pencil"></i></button>
                                            <button class="btn btn-sm btn-outline-danger"><i class="fa fa-trash"></i></button>
                                        </td>
                                    </tr>
                                    <% } %>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <div class="modal fade" id="users-modal" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title">Registered Users</h5>
                    <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <table class="table table-bordered">
                        <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th></tr></thead>
                        <tbody>
                            <% for(User u : userList) { %>
                            <tr>
                                <td><%= u.getUserId() %></td>
                                <td><%= u.getUserName() %></td>
                                <td><%= u.getUserEmail() %></td>
                                <td><%= u.getUserType() %></td>
                            </tr>
                            <% } %>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <div class="modal fade" id="categories-modal" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-warning text-white">
                    <h5 class="modal-title">All Categories</h5>
                    <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <ul class="list-group">
                        <% for(Category c : clist) { %>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <%= c.getCategoryTitle() %>
                            <span class="badge badge-primary badge-pill"><%= c.getProducts().size() %> products</span>
                        </li>
                        <% } %>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
    <div class="modal fade" id="products-modal" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-xl"> <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title">Product Inventory</h5>
                    <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <table class="table table-striped">
                        <thead><tr><th>Name</th><th>Price</th><th>Category</th></tr></thead>
                        <tbody>
                            <% for(Product p : plist) { %>
                            <tr>
                                <td><%= p.getpName() %></td>
                                <td>&#8377; <%= p.getpPrice() %></td>
                                <td><%= p.getCategory().getCategoryTitle() %></td>
                            </tr>
                            <% } %>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="add-category-modal" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-success text-white">
                    <h5 class="modal-title">Add New Category</h5>
                    <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <form action="ProductOperationServlet" method="post">
                        <input type="hidden" name="operation" value="addcategory">
                        <div class="form-group">
                            <input type="text" class="form-control" name="catTitle" placeholder="Category Title" required />
                        </div>
                        <div class="form-group">
                            <textarea class="form-control" name="catDescription" placeholder="Description" required></textarea>
                        </div>
                        <div class="text-center">
                            <button class="btn btn-outline-success">Add Category</button>
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="add-product-modal" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-warning text-white">
                    <h5 class="modal-title">Add New Product</h5>
                    <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <form action="ProductOperationServlet" method="post" enctype="multipart/form-data">
                        <input type="hidden" name="operation" value="addproduct">
                        
                        <div class="form-group">
                            <input type="text" class="form-control" name="pName" placeholder="Product Name" required />
                        </div>
                        <div class="form-group">
                            <textarea class="form-control" name="pDesc" placeholder="Product Description" required></textarea>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-4">
                                <input type="number" class="form-control" name="pPrice" placeholder="Price" required />
                            </div>
                            <div class="form-group col-md-4">
                                <input type="number" class="form-control" name="pDiscount" placeholder="Discount %" required />
                            </div>
                            <div class="form-group col-md-4">
                                <input type="number" class="form-control" name="pQuantity" placeholder="Quantity" required />
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label>Category</label>
                            <select name="catId" class="form-control">
                                <% for(Category c : clist) { %>
                                    <option value="<%= c.getCategoryId() %>"> <%= c.getCategoryTitle() %> </option>
                                <% } %>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label>Product Image</label>
                            <input type="file" name="pPic" class="form-control" required />
                        </div>
                        
                        <div class="text-center">
                            <button class="btn btn-warning">Add Product</button>
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    
</body>
</html>