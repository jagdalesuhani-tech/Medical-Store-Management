<%@ page language="java" contentType="text/html; charset=ISO-8859-1" pageEncoding="ISO-8859-1"%>
<%@ page import="com.medical.entities.User" %>
<%@ page import="com.medical.dao.CategoryDao" %>
<%@ page import="com.medical.entities.Category" %>
<%@ page import="com.medical.helper.FactoryProvider" %>
<%@ page import="java.util.List" %>

<%
    // 1. Security Check: Ensure user is logged in
    User user = (User) session.getAttribute("current-user");
    if (user == null) {
        session.setAttribute("message", "You are not logged in! Login first.");
        response.sendRedirect("../login.jsp");
        return;
    }
    
    // 2. Fetch Categories for the Dropdown
    CategoryDao cdao = new CategoryDao(FactoryProvider.getFactory());
    List<Category> list = cdao.getCategories();
%>

<!DOCTYPE html>
<html>
<head>
    <title>Add Product</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #e9ecef; padding: 20px; }
        .form-container { background: white; max-width: 500px; margin: 30px auto; padding: 30px; border-radius: 10px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }
        h2 { text-align: center; color: #333; margin-bottom: 20px; }
        
        label { font-weight: bold; display: block; margin-top: 10px; color: #555; }
        input, textarea, select { width: 100%; padding: 10px; margin-top: 5px; margin-bottom: 15px; border: 1px solid #ddd; border-radius: 5px; box-sizing: border-box; font-size: 14px; }
        textarea { resize: vertical; }
        
        button { width: 100%; padding: 12px; background: #28a745; color: white; border: none; border-radius: 5px; font-size: 16px; cursor: pointer; transition: background 0.3s; }
        button:hover { background: #218838; }
        
        /* Alert Message Styling */
        .alert { padding: 10px; margin-bottom: 15px; border-radius: 5px; text-align: center; }
        .alert-success { background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .alert-danger { background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
    </style>
</head>
<body>

    <div class="form-container">
        
        <%
            String message = (String) session.getAttribute("message");
            if(message != null) {
        %>
            <div class="alert alert-success">
                <%= message %>
            </div>
        <%
                session.removeAttribute("message"); // Remove after showing so it doesn't stick
            }
        %>

        <h2>Add New Medicine</h2>
        
        <form action="../ProductOperationServlet" method="post" enctype="multipart/form-data">
            
            <input type="hidden" name="operation" value="addproduct">
            
            <label>Medicine Name</label>
            <input type="text" name="pName" placeholder="Enter medicine name" required>
            
            <label>Description</label>
            <textarea name="pDesc" placeholder="Enter product description" style="height: 100px;"></textarea>
            
            <div style="display: flex; gap: 10px;">
                <div style="flex: 1;">
                    <label>Price</label>
                    <input type="number" name="pPrice" placeholder="Price" required>
                </div>
                <div style="flex: 1;">
                    <label>Discount (%)</label>
                    <input type="number" name="pDiscount" placeholder="Discount">
                </div>
            </div>
            
            <label>Quantity</label>
            <input type="number" name="pQuantity" placeholder="Quantity Available" required>
            
            <label>Select Category</label>
            <select name="catId" required>
                <option value="" disabled selected>-- Select Category --</option>
                <% 
                    for(Category c : list) { 
                %>
                    <option value="<%= c.getCategoryId() %>"> <%= c.getCategoryTitle() %> </option>
                <% 
                    } 
                %>
            </select>
            
            <label>Product Image</label>
            <input type="file" name="pPic" required>
            
            <button type="submit">Add Product</button>
            
        </form>
    </div>

</body>
</html>