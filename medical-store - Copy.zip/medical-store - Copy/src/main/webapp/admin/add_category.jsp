<%@ page language="java" contentType="text/html; charset=ISO-8859-1" pageEncoding="ISO-8859-1"%>
<%@ page import="com.medical.entities.User" %>
<%
    User user = (User) session.getAttribute("current-user");
    if (user == null) {
        session.setAttribute("message", "You are not logged in!");
        response.sendRedirect("../login.jsp");
        return;
    } else if (user.getUserType().equals("normal")) {
        session.setAttribute("message", "You are not Admin! Access Denied.");
        response.sendRedirect("../login.jsp");
        return;
    }
%>

<!DOCTYPE html>
<html>
<head>
    <title>Add Category</title>
    <style>
        body { font-family: sans-serif; background-color: #f4f7f6; display: flex; justify-content: center; padding-top: 50px;}
        .form-card { background: white; width: 400px; padding: 30px; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
        h2 { text-align: center; color: #2c3e50; }
        input, textarea { width: 100%; padding: 10px; margin: 10px 0; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box;}
        button { width: 100%; padding: 10px; background: #27ae60; color: white; border: none; cursor: pointer; font-size: 16px;}
        button:hover { background: #219150; }
        .back-link { display: block; text-align: center; margin-top: 15px; text-decoration: none; color: #7f8c8d; }
    </style>
</head>
<body>

    <div class="form-card">
        <h2>Add New Category</h2>
        <form action="../ProductOperationServlet" method="post">
            
            <input type="hidden" name="operation" value="addcategory">
            
            <label>Category Title</label>
            <input type="text" name="catTitle" placeholder="e.g. Antibiotics" required>
            
            <label>Category Description</label>
            <textarea name="catDescription" rows="4" placeholder="Enter short description"></textarea>
            
            <button type="submit">Add Category</button>
        </form>
        
        <a href="dashboard.jsp" class="back-link">Back to Dashboard</a>
    </div>

</body>
</html>