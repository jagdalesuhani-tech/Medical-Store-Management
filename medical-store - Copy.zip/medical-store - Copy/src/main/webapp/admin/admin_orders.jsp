<%@ page language="java" contentType="text/html; charset=ISO-8859-1" pageEncoding="ISO-8859-1"%>
<%@ page import="com.medical.entities.*" %>
<%@ page import="com.medical.dao.OrderDao" %>
<%@ page import="com.medical.helper.FactoryProvider" %>
<%@ page import="java.util.List" %>

<%
    // Authorization Check
    User user = (User) session.getAttribute("current-user");
    if(user == null) {
        session.setAttribute("message", "You are not logged in!");
        response.sendRedirect("../login.jsp");
        return;
    } else {
        if(user.getUserType().equals("normal")) {
            session.setAttribute("message", "You are not an Admin!");
            response.sendRedirect("../login.jsp");
            return;
        }
    }
%>

<!DOCTYPE html>
<html>
<head>
    <title>Admin - Manage Orders</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../css/style.css">
    
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap');

        body {
            font-family: 'Poppins', sans-serif !important;
            /* Applying your background image */
            background: url('../img/body-bg.jpg?v=2') no-repeat center center fixed;
            background-size: cover;
        }

        /* Frosted Glass Wrapper */
        .glass-wrapper {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            min-height: 100vh;
            padding-top: 30px;
            padding-bottom: 50px;
        }

        /* Central Glass Card */
        .glass-card {
            background: rgba(255, 255, 255, 0.92);
            border-radius: 20px;
            border: 1px solid rgba(255, 255, 255, 0.4);
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            overflow: hidden;
        }

        /* Professional Table Header */
        .table thead th {
            background: #32aeb1; /* Medical Teal Theme */
            color: white;
            border: none;
            font-weight: 600;
            padding: 15px;
            text-transform: uppercase;
            font-size: 13px;
        }

        .table td {
            padding: 15px;
            vertical-align: middle !important;
        }

        /* Status Badges */
        .badge-soft {
            font-weight: 600;
            border-radius: 50px;
            padding: 6px 15px;
            font-size: 11px;
        }

        /* Custom Scrollbar for Items Column */
        .items-list {
            max-height: 100px;
            overflow-y: auto;
        }
    </style>
</head>
<body>

    <%@ include file="../components/navbar.jsp" %>

    <div class="glass-wrapper">
        <div class="container-fluid px-lg-5">
            
            <div class="row">
                <div class="col-md-12">
                    <% 
                        String msg = (String) session.getAttribute("message");
                        if(msg != null) {
                    %>
                        <div class="alert alert-success alert-dismissible fade show rounded-pill px-4 shadow-sm border-0">
                            <strong><i class="fas fa-check-circle mr-2"></i></strong> <%= msg %>
                            <button type="button" class="close" data-dismiss="alert">&times;</button>
                        </div>
                    <% 
                        session.removeAttribute("message");
                        } 
                    %>
                </div>
            </div>

            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h2 class="text-dark font-weight-bold m-0">Order Management</h2>
                    <p class="text-muted small">Process and track customer medicine orders</p>
                </div>
                <a href="dashboard.jsp" class="btn btn-light btn-sm rounded-pill px-4 shadow-sm border">
                    <i class="fas fa-th-large mr-2 text-primary"></i> Dashboard
                </a>
            </div>

            <div class="glass-card shadow-lg">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th>Order ID</th>
                                <th>Customer Details</th>
                                <th>Items Ordered</th>
                                <th>Total Amount</th>
                                <th>Status</th>
                                <th>Update Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <%
                                // Fetching Orders through DAO
                                OrderDao oDao = new OrderDao(FactoryProvider.getFactory());
                                List<Order> list = oDao.getAllOrders();
                                
                                for(Order o : list) {
                                    // Status color logic
                                    String s = o.getOrderStatus();
                                    String color = "secondary";
                                    if(s.equals("Placed")) color = "primary";
                                    else if(s.equals("Confirmed")) color = "info";
                                    else if(s.equals("Shipped")) color = "warning text-dark";
                                    else if(s.equals("Delivered")) color = "success";
                                    else if(s.equals("Cancelled")) color = "danger";
                            %>
                            <tr>
                                <td><span class="font-weight-bold text-primary">#<%= o.getOrderId() %></span></td>
                                
                                <td>
                                    <div class="font-weight-bold"><%= o.getUser().getUserName() %></div>
                                    <small class="text-muted"><i class="fas fa-phone-alt mr-1"></i> <%= o.getUser().getUserPhone() %></small><br>
                                    <small class="text-muted d-block mt-1" style="max-width: 200px;"><i class="fas fa-map-marker-alt mr-1"></i> <%= o.getUser().getUserAddress() %></small>
                                </td>
                                
                                <td>
                                    <div class="items-list">
                                        <% for(OrderDetail d : o.getOrderDetails()) { %>
                                            <div class="small border-bottom py-1">
                                                <i class="fas fa-pills text-info mr-1"></i> 
                                                <%= d.getProduct().getpName() %> 
                                                <span class="text-muted">(x<%= d.getQuantity() %>)</span>
                                            </div>
                                        <% } %>
                                    </div>
                                </td>
                                
                                <td>
                                    <span class="h5 font-weight-bold text-dark">&#8377;<%= o.getTotalAmount() %></span>
                                </td>
                                
                                <td>
                                    <span class="badge badge-<%= color %> badge-soft text-uppercase">
                                        <%= s %>
                                    </span>
                                </td>
                                
                                <td>
                                    <% if(!s.equals("Cancelled") && !s.equals("Delivered")) { %>
                                    
                                    <form action="../ProductOperationServlet" method="post" class="form-inline">
                                        <input type="hidden" name="operation" value="update_status">
                                        <input type="hidden" name="order_id" value="<%= o.getOrderId() %>">
                                        
                                        <div class="input-group">
                                            <select name="status" class="form-control form-control-sm custom-select" style="border-radius: 10px 0 0 10px; width: 120px; font-size: 12px;">
                                                <option value="Placed" <%= s.equals("Placed")?"selected":"" %>>Placed</option>
                                                <option value="Confirmed" <%= s.equals("Confirmed")?"selected":"" %>>Confirmed</option>
                                                <option value="Shipped" <%= s.equals("Shipped")?"selected":"" %>>Shipped</option>
                                                <option value="Delivered" <%= s.equals("Delivered")?"selected":"" %>>Delivered</option>
                                                <option value="Cancelled" <%= s.equals("Cancelled")?"selected":"" %>>Cancel</option>
                                            </select>
                                            <div class="input-group-append">
                                                <button class="btn btn-sm btn-dark" style="border-radius: 0 10px 10px 0;">
                                                    <i class="fas fa-save"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </form>
                                    
                                    <% } else { %>
                                        <span class="text-success small font-weight-bold">
                                            <i class="fas fa-check-double mr-1"></i> Finalized
                                        </span>
                                    <% } %>
                                </td>
                            </tr>
                            <% } %>
                        </tbody>
                    </table>
                    
                    <% if(list.isEmpty()) { %>
                        <div class="text-center py-5">
                            <i class="fas fa-box-open fa-3x text-muted mb-3"></i>
                            <h4 class="text-muted">No orders found in the database.</h4>
                        </div>
                    <% } %>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>
</html>