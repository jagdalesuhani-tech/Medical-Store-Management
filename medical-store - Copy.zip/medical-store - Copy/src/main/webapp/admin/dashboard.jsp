<%@ page language="java" contentType="text/html; charset=ISO-8859-1" pageEncoding="ISO-8859-1"%>
<%@ page import="com.medical.entities.User" %>
<%@ page import="com.medical.dao.*" %>
<%@ page import="com.medical.entities.*" %>
<%@ page import="com.medical.helper.FactoryProvider" %>
<%@ page import="java.util.List" %>
<%@ page import="com.medical.helper.Helper" %>

<%
    // Authorization Check: Ensuring only Admins access this folder
    User user = (User) session.getAttribute("current-user");
    if (user == null) {
        session.setAttribute("message", "You are not logged in! Login first.");
        response.sendRedirect("../login.jsp");
        return;
    } else if (user.getUserType().equals("normal")) {
        session.setAttribute("message", "Access Denied! Admin permissions required.");
        response.sendRedirect("../login.jsp");
        return;
    }

    // Initialize DAOs
    UserDao udao = new UserDao(FactoryProvider.getFactory());
    List<User> userList = udao.getAllUsers();

    CategoryDao catDao = new CategoryDao(FactoryProvider.getFactory());
    List<Category> clist = catDao.getCategories();

    ProductDao pdao = new ProductDao(FactoryProvider.getFactory());
    List<Product> plist = pdao.getAllProducts();
%>

<!DOCTYPE html>
<html>
<head>
    <title>MediCare - Admin Dashboard</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../css/style.css">
    
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap');

        body {
            font-family: 'Poppins', sans-serif !important;
            background-image: url('../img/body-bg.jpg?v=2'); 
            background-attachment: fixed;
            background-size: cover;
            background-position: center;
        }

        .glass-overlay {
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(10px);
            min-height: 100vh;
            padding-bottom: 50px;
        }

        .admin .card {
            border: 1px solid rgba(255, 227, 232, 0.6);
            border-radius: 20px;
            background: rgba(255, 255, 255, 0.92);
            box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.1);
            transition: all 0.3s ease;
            overflow: hidden;
        }

        .admin .card:hover {
            transform: translateY(-8px);
            box-shadow: 0 15px 30px rgba(255, 143, 163, 0.3);
            background: #ffffff;
            cursor: pointer;
        }

        .stat-icon-wrap {
            width: 70px; height: 70px;
            display: flex; align-items: center; justify-content: center;
            border-radius: 50%; margin: 0 auto 15px;
            font-size: 26px;
        }

        .bg-med-blue { background: #e3f2fd; color: #007bff; }
        .bg-med-yellow { background: #fff8e1; color: #ffc107; }
        .bg-med-red { background: #ffebee; color: #dc3545; }
        .bg-med-green { background: #e8f5e9; color: #28a745; }

        .table thead th {
            background-color: #f8f9fa;
            border-bottom: 2px solid #dee2e6;
            text-transform: uppercase;
            font-size: 12px;
            font-weight: 600;
        }
    </style>
</head>
<body>

    <div class="glass-overlay">
        <%@ include file="../components/navbar.jsp" %>

        <div class="container admin mt-4">
            
            <div class="container-fluid mb-4">
                <%@ include file="../components/message.jsp" %>
                
                <% 
                    int lowStockItems = 0;
                    for(Product p : plist) { if(p.getpQuantity() < 10) lowStockItems++; }
                    if(lowStockItems > 0) {
                %>
                <div class="alert alert-warning border-0 shadow-sm rounded-pill px-4">
                    <i class="fas fa-exclamation-triangle mr-2 text-danger"></i> 
                    <strong>Inventory Alert:</strong> <%= lowStockItems %> medicines are low on stock.
                </div>
                <% } %>
            </div>

            <%-- DASHBOARD CARDS --%>
            <div class="row">
                <div class="col-md-3 mb-4">
                    <div class="card text-center p-4 h-100" data-toggle="modal" data-target="#users-modal">
                        <div class="stat-icon-wrap bg-med-blue"><i class="fas fa-user-md"></i></div>
                        <h2 class="font-weight-bold m-0"><%= userList.size() %></h2>
                        <p class="text-muted text-uppercase small mb-0">Users</p>
                    </div>
                </div>

                <div class="col-md-3 mb-4">
                    <div class="card text-center p-4 h-100" data-toggle="modal" data-target="#view-categories-modal">
                        <div class="stat-icon-wrap bg-med-yellow"><i class="fas fa-th-large"></i></div>
                        <h2 class="font-weight-bold m-0"><%= clist.size() %></h2>
                        <p class="text-muted text-uppercase small mb-0">Categories</p>
                    </div>
                </div>

                <%-- FIXED MEDICINE CARD: Correct data-target --%>
                <div class="col-md-3 mb-4">
                    <div class="card text-center p-4 h-100" data-toggle="modal" data-target="#view-products-modal">
                        <div class="stat-icon-wrap bg-med-red"><i class="fas fa-pills"></i></div>
                        <h2 class="font-weight-bold m-0"><%= plist.size() %></h2>
                        <p class="text-muted text-uppercase small mb-0">Medicines</p>
                    </div>
                </div>

                <div class="col-md-3 mb-4">
                    <div class="card text-center p-4 h-100" onclick="window.location='admin_orders.jsp'">
                        <div class="stat-icon-wrap bg-med-green"><i class="fas fa-shipping-fast"></i></div>
                        <h2 class="font-weight-bold m-0">View</h2>
                        <p class="text-muted text-uppercase small mb-0">Orders</p>
                    </div>
                </div>
            </div>

            <%-- ACTION BUTTONS --%>
            <div class="row mb-4 text-center">
                <div class="col-md-6 mb-3">
                    <div class="card p-4" data-toggle="modal" data-target="#add-category-modal">
                        <i class="fas fa-folder-plus fa-3x text-info mb-2"></i>
                        <h5 class="font-weight-bold text-uppercase m-0">New Category</h5>
                    </div>
                </div>
                <div class="col-md-6 mb-3">
                    <div class="card p-4" onclick="window.location='add_product.jsp'">
                        <i class="fas fa-cart-plus fa-3x text-success mb-2"></i>
                        <h5 class="font-weight-bold text-uppercase m-0">New Medicine</h5>
                    </div>
                </div>
            </div>

            <%-- INVENTORY TABLE --%>
            <div class="row">
                <div class="col-md-12">
                    <div class="card border-0">
                        <div class="card-header bg-white py-3">
                            <h5 class="font-weight-bold mb-0">Medicine Inventory</h5>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover mb-0 text-center">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Name</th>
                                            <th>Price</th>
                                            <th>Stock</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <% for (Product p : plist) { %>
                                        <tr>
                                            <td class="align-middle">#<%= p.getpId() %></td>
                                            <td class="font-weight-bold align-middle text-dark"><%= p.getpName() %></td>
                                            <td class="align-middle text-success font-weight-bold">&#8377; <%= p.getpPrice() %></td>
                                            <td class="align-middle">
                                                <% if(p.getpQuantity() < 10) { %>
                                                    <span class="badge badge-danger p-2 px-3 rounded-pill">Low: <%= p.getpQuantity() %></span>
                                                <% } else { %>
                                                    <span class="badge badge-light p-2 border rounded-pill px-3 text-dark"><%= p.getpQuantity() %> Units</span>
                                                <% } %>
                                            </td>
                                            <td class="align-middle">
                                                <a href="update_product.jsp?product_id=<%= p.getpId() %>" class="btn btn-sm btn-outline-primary rounded-pill px-3">Edit</a>
                                                <button onclick="deleteProduct(<%= p.getpId() %>)" class="btn btn-sm btn-outline-danger rounded-pill px-3">Delete</button>
                                            </td>
                                        </tr>
                                        <% } %>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <%-- MODALS SECTION --%>

    <%-- 1. VIEW USERS MODAL --%>
    <div class="modal fade" id="users-modal" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-lg">
            <div class="modal-content" style="border-radius: 20px; overflow: hidden;">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title font-weight-bold">System Users</h5>
                    <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body p-0">
                    <table class="table table-hover mb-0 text-center">
                        <thead class="bg-light"><tr><th>ID</th><th>Name</th><th>Email</th><th>Type</th><th>Action</th></tr></thead>
                        <tbody>
                            <% for(User u : userList) { %>
                            <tr>
                                <td><%= u.getUserId() %></td>
                                <td><b><%= u.getUserName() %></b></td>
                                <td><%= u.getUserEmail() %></td>
                                <td><span class="badge badge-info px-2"><%= u.getUserType() %></span></td>
                                <td>
                                    <% if(user.getUserId() != u.getUserId()) { %>
                                        <button onclick="deleteUser(<%= u.getUserId() %>)" class="btn btn-sm btn-danger rounded-circle"><i class="fa fa-trash"></i></button>
                                    <% } %>
                                </td>
                            </tr>
                            <% } %>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <%-- 2. ADD CATEGORY MODAL --%>
    <div class="modal fade" id="add-category-modal" tabindex="-1" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content" style="border-radius: 20px;">
                <div class="modal-header bg-success text-white">
                    <h5 class="modal-title font-weight-bold">New Category</h5>
                    <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body p-4">
                    <form action="../ProductOperationServlet" method="post">
                        <input type="hidden" name="operation" value="addcategory">
                        <div class="form-group"><input type="text" class="form-control" name="catTitle" placeholder="Category Title" required /></div>
                        <div class="form-group"><textarea class="form-control" name="catDescription" rows="3" placeholder="Description" required></textarea></div>
                        <div class="text-right"><button class="btn btn-success rounded-pill px-4">Add Category</button></div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <%-- 3. VIEW CATEGORIES MODAL --%>
    <div class="modal fade" id="view-categories-modal" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-lg">
            <div class="modal-content" style="border-radius: 20px; overflow: hidden;">
                <div class="modal-header bg-warning text-white">
                    <h5 class="modal-title font-weight-bold">Categories</h5>
                    <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body p-0">
                    <table class="table mb-0 text-center">
                        <thead class="bg-light"><tr><th>ID</th><th>Title</th><th>Description</th></tr></thead>
                        <tbody><% for(Category c : clist) { %><tr><td><%= c.getCategoryId() %></td><td><b><%= c.getCategoryTitle() %></b></td><td><%= c.getCategoryDescription() %></td></tr><% } %></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <%-- 4. VIEW MEDICINES MODAL (ADDED) --%>
    <div class="modal fade" id="view-products-modal" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-lg">
            <div class="modal-content" style="border-radius: 20px; overflow: hidden;">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title font-weight-bold">All Medicines</h5>
                    <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body p-0">
                    <table class="table table-striped mb-0 text-center">
                        <thead><tr><th>Name</th><th>Price</th><th>Category</th></tr></thead>
                        <tbody>
                            <% for(Product p : plist) { %>
                            <tr>
                                <td><b><%= p.getpName() %></b></td>
                                <td class="text-success font-weight-bold">&#8377; <%= p.getpPrice() %></td>
                                <td><%= p.getCategory().getCategoryTitle() %></td>
                            </tr>
                            <% } %>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <%-- SCRIPTS --%>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script>
        function deleteProduct(pid) { if(confirm("Delete this medicine?")) window.location = "../DeleteServlet?product_id=" + pid; }
        function deleteUser(uid) { if(confirm("Delete this user?")) window.location = "../DeleteServlet?user_id=" + uid; }
    </script>
</body>
</html>