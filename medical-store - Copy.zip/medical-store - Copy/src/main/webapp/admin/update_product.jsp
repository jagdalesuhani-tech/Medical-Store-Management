<%@ page language="java" contentType="text/html; charset=ISO-8859-1" pageEncoding="ISO-8859-1"%>
<%@ page import="com.medical.entities.*, com.medical.dao.*, com.medical.helper.*, java.util.*" %>

<%
    User user = (User) session.getAttribute("current-user");
    if (user == null) {
        response.sendRedirect("../login.jsp");
        return;
    }

    // 1. GET THE PRODUCT ID FROM URL
    int pid = Integer.parseInt(request.getParameter("product_id"));
    
    // 2. FETCH PRODUCT DATA
    ProductDao pdao = new ProductDao(FactoryProvider.getFactory());
    Product p = pdao.getProductById(pid);
    
    // 3. FETCH CATEGORIES FOR DROPDOWN
    CategoryDao cdao = new CategoryDao(FactoryProvider.getFactory());
    List<Category> list = cdao.getCategories();
%>

<!DOCTYPE html>
<html>
<head>
    <title>Update Product</title>
    <style>
        body { font-family: sans-serif; background-color: #e9ecef; padding: 20px; }
        .form-container { background: white; max-width: 500px; margin: 30px auto; padding: 30px; border-radius: 10px; }
        input, textarea, select { width: 100%; padding: 10px; margin: 10px 0; }
        button { width: 100%; padding: 10px; background: #007bff; color: white; border: none; cursor: pointer; }
    </style>
</head>
<body>
    <div class="form-container">
        <h2 style="text-align:center;">Update Medicine</h2>

        <form action="../ProductOperationServlet" method="post" enctype="multipart/form-data">
            
            <input type="hidden" name="operation" value="updateproduct">
            <input type="hidden" name="pId" value="<%= p.getpId() %>">
            <input type="hidden" name="oldPic" value="<%= p.getpPhoto() %>">

            <label>Medicine Name</label>
            <input type="text" name="pName" value="<%= p.getpName() %>" required>

            <label>Description</label>
            <textarea name="pDesc" style="height: 100px;"><%= p.getpDesc() %></textarea>

            <label>Price</label>
            <input type="number" name="pPrice" value="<%= p.getpPrice() %>" required>

            <label>Discount (%)</label>
            <input type="number" name="pDiscount" value="<%= p.getpDiscount() %>">

            <label>Quantity</label>
            <input type="number" name="pQuantity" value="<%= p.getpQuantity() %>" required>

            <label>Category</label>
            <select name="catId">
                <% for(Category c : list) { %>
                    <option value="<%= c.getCategoryId() %>" 
                        <%= c.getCategoryId() == p.getCategory().getCategoryId() ? "selected" : "" %>> 
                        <%= c.getCategoryTitle() %> 
                    </option>
                <% } %>
            </select>

            <label>Product Image (Leave empty to keep current)</label>
            <br>
            <img src="../img/products/<%= p.getpPhoto() %>" style="width: 80px; height: 80px; object-fit: cover; margin-bottom: 10px;">
            <input type="file" name="pPic">

            <button type="submit">Update Product</button>
        </form>
    </div>
</body>
</html>