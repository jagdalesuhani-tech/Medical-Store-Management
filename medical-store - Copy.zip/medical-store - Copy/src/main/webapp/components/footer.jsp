<style>
    .footer {
        background: #1a1a1a;
        color: #fff;
        padding-top: 40px;
        margin-top: 50px;
        font-family: 'Poppins', sans-serif;
    }
    .footer h5 {
        color: #32aeb1; /* Your Theme Color */
        font-weight: 700;
        margin-bottom: 20px;
    }
    .footer a {
        color: #bbb;
        text-decoration: none;
        display: block;
        margin-bottom: 10px;
        transition: color 0.3s;
    }
    .footer a:hover {
        color: #fff;
        padding-left: 5px;
    }
    .footer-bottom {
        background: #000;
        padding: 15px;
        text-align: center;
        margin-top: 30px;
        font-size: 14px;
        color: #777;
    }
</style>

<footer class="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <h5>MediCare</h5>
                <p class="text-muted small">
                    MediCare is your trusted online pharmacy. We provide genuine medicines, 
                    fast delivery, and expert advice. Your health is our priority.
                </p>
                <div class="mt-3">
                    <a href="#" class="d-inline mr-2"><i class="fa fa-facebook"></i></a>
                    <a href="#" class="d-inline mr-2"><i class="fa fa-twitter"></i></a>
                    <a href="#" class="d-inline mr-2"><i class="fa fa-instagram"></i></a>
                </div>
            </div>

            <div class="col-md-4">
                <h5>Quick Links</h5>
                <a href="index.jsp">Home</a>
                <a href="about.jsp">About Us</a>
                <a href="contact.jsp">Contact Support</a>
                <a href="login.jsp">Login / Register</a>
            </div>

            <div class="col-md-4">
                <h5>Contact Us</h5>
                <p class="small text-muted mb-1"><i class="fa fa-map-marker"></i> Vihighar, Matheran Road, Panvel, India</p>
                <p class="small text-muted mb-1"><i class="fa fa-phone"></i> +91 99878 91705</p>
                <p class="small text-muted mb-1"><i class="fa fa-envelope"></i> omkardhanavade2005@gmail.com</p>
            </div>
        </div>
    </div>
    
    <div class="footer-bottom">
        &copy; 2024 MediCare. All rights reserved. | Designed with <i class="fa fa-heart text-danger"></i> in India.
    </div>
</footer>