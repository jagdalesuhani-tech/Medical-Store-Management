<%@ page language="java" contentType="text/html; charset=ISO-8859-1" pageEncoding="ISO-8859-1"%>
<%@ page import="com.medical.entities.User" %>
<%@ page import="com.medical.entities.Category" %>
<%@ page import="com.medical.dao.CategoryDao" %>
<%@ page import="com.medical.helper.FactoryProvider" %>
<%@ page import="com.medical.helper.CartItem" %>
<%@ page import="java.util.List" %>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<%
    User user1 = (User) session.getAttribute("current-user");
    String path = request.getContextPath();
    List<CartItem> cartList = (List<CartItem>) session.getAttribute("cart-list");
    int itemCount = (cartList != null) ? cartList.size() : 0;
%>

<style>
    /* ========================================= */
    /* 1. MAIN WRAPPER (BACKGROUND IMAGE HERE)   */
    /* ========================================= */
    .navbar-main-wrapper {
        /* This path must be correct. 'img/navbar-bg.jpg' */
        background-image: linear-gradient(rgba(0, 48, 73, 0.9), rgba(0, 48, 73, 0.9)), 
                          url('img/navbar-bg.jpg'); 
        
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        width: 100%;
        display: block;
        position: relative;
    }

    /* 2. Top Section (FORCE TRANSPARENT) */
    .netmeds-top {
        background: transparent !important; /* The !important forces it to be see-through */
        background-color: rgba(0,0,0,0) !important;
        border-bottom: 1px solid rgba(255,255,255,0.1);
        padding-top: 15px;
        padding-bottom: 15px;
        color: white;
    }

    /* 3. Bottom Section (FORCE TRANSPARENT) */
    .netmeds-bottom {
        background: transparent !important;
        background-color: rgba(0,0,0,0) !important;
        padding-top: 5px;
        padding-bottom: 5px;
    }

    /* 4. Navbar Links */
    .netmeds-nav-link { font-size: 14px; font-weight: 600; margin-right: 15px; transition: all 0.3s; display: flex; align-items: center; color: rgba(255,255,255,0.85) !important; }
    .netmeds-nav-link:hover { color: #fff !important; background: rgba(255,255,255,0.15); border-radius: 5px; transform: translateY(-2px); }
    .nav-icon { margin-right: 8px; font-size: 16px; }

    /* 5. Icon Colors */
    .icon-baby { color: #ffc107; } 
    .icon-heart { color: #dc3545; } 
    .icon-leaf { color: #28a745; } 
    .icon-flask { color: #17a2b8; } 
    .icon-default { color: #ffffff; }

    /* 6. Animations */
    .live-dot { height: 10px; width: 10px; background-color: #ff0000; border-radius: 50%; display: inline-block; margin-right: 5px; box-shadow: 0 0 5px #ff0000; animation: blink 1.5s infinite; }
    @keyframes blink { 0% { opacity: 1; } 50% { opacity: 0.4; } 100% { opacity: 1; } }
    
    .moving-truck { display: inline-block; animation: drive 1s infinite alternate; color: #fff; }
    @keyframes drive { 0% { transform: translateY(0); } 100% { transform: translateY(-2px); } }
</style>

<div class="navbar-main-wrapper">

    <div class="container-fluid netmeds-top">
        <div class="container">
            <div class="row align-items-center">
                
                <div class="col-md-3 d-flex align-items-center">
                    <a href="<%= path %>/index.jsp" class="text-white" style="font-size: 24px; font-weight: bold; text-decoration: none;">
                        <i class="fa fa-plus-square">&nbsp;</i> MediCare
                    </a>
                    
                    <span class="location-text ml-3" onclick="changePincode()" style="cursor: pointer;">
                        <span class="live-dot"></span> 
                        <span>Deliver to <strong id="pincode_display">Detecting...</strong> <i class="fa fa-pencil" style="font-size:10px;"></i></span>
                    </span>
                </div>

                <div class="col-md-6">
                    <form action="<%= path %>/index.jsp" method="get">
                        <div class="search-container mx-auto">
                            <i class="fa fa-search text-muted">&nbsp;</i>
                            <input type="text" name="search" placeholder="Search for medicines...">
                        </div>
                    </form>
                </div>

                <div class="col-md-3 text-right text-white">
                    <a href="<%= path %>/cart.jsp" class="text-white mr-4" style="text-decoration: none;">
                        <i class="fa fa-shopping-cart">&nbsp;</i> Cart 
                        <span class="badge badge-warning"><%= itemCount %></span>
                    </a>

                    <% if (user1 == null) { %>
                        <a href="<%= path %>/login.jsp" class="text-white" style="text-decoration: none;">
                            <i class="fa fa-user">&nbsp;</i> Sign In
                        </a>
                    <% } else { %>
                        <a href="<%= path %>/profile.jsp" class="text-white" style="text-decoration: none; font-weight: bold;">
                            <i class="fa fa-user-circle">&nbsp;</i> <%= user1.getUserName() %>
                        </a>
                        <a href="<%= path %>/LogoutServlet" class="text-white ml-2" style="font-size: 12px;">(Logout)</a>
                    <% } %>
                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid netmeds-bottom d-none d-md-block">
        <div class="container">
            <nav class="nav">
                <a class="nav-link netmeds-nav-link" href="<%= path %>/index.jsp?category=all">
                    <i class="fa fa-bars nav-icon">&nbsp;</i> All
                </a>

                <%
                    CategoryDao cdao = new CategoryDao(FactoryProvider.getFactory());
                    List<Category> navbarCategories = cdao.getCategories();
                    
                    for(Category c : navbarCategories) {
                        String title = c.getCategoryTitle().toLowerCase();
                        String iconClass = "fa-medkit"; 
                        String colorClass = "icon-default";
                        
                        if(title.contains("baby") || title.contains("kid")) { iconClass = "fa-child"; colorClass = "icon-baby"; } 
                        else if(title.contains("cardio") || title.contains("heart")) { iconClass = "fa-heartbeat"; colorClass = "icon-heart"; }
                        else if(title.contains("ayurveda") || title.contains("herbal")) { iconClass = "fa-leaf"; colorClass = "icon-leaf"; }
                        else if(title.contains("lab") || title.contains("test")) { iconClass = "fa-flask"; colorClass = "icon-flask"; }
                        else if(title.contains("device") || title.contains("equip")) { iconClass = "fa-stethoscope"; }
                %>
                    <a class="nav-link netmeds-nav-link" href="<%= path %>/index.jsp?category=<%= c.getCategoryId() %>">
                        <i class="fa <%= iconClass %> nav-icon <%= colorClass %>">&nbsp;</i> <%= c.getCategoryTitle() %>
                    </a>
                <% } %>

                <% if(user1 != null && user1.getUserType().equals("normal")) { %>
                    <a class="nav-link netmeds-nav-link ml-auto bg-info text-white rounded px-2" href="<%= path %>/my_orders.jsp">
                        <i class="fa fa-truck moving-truck" style="margin-right: 8px;"></i> My Orders
                    </a>
                <% } %>

                <% if(user1 != null && user1.getUserType().equals("admin")) { %>
                    <a class="nav-link netmeds-nav-link ml-auto bg-danger text-white rounded px-2" href="<%= path %>/admin/dashboard.jsp">
                        <i class="fa fa-lock nav-icon">&nbsp;</i> Admin
                    </a>
                <% } %>
                
            </nav>
        </div>
    </div>

</div> 
<div class="mb-3"></div>

<script>
    window.onload = function() {
        if(document.getElementById("pincode_display").innerHTML === "Detecting...") {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(showPosition, showError);
            } else {
                document.getElementById("pincode_display").innerHTML = "110001";
            }
        }
    };
    function showPosition(position) {
        let lat = position.coords.latitude;
        let lon = position.coords.longitude;
        let api_url = "https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=" + lat + "&lon=" + lon;
        fetch(api_url).then(response => response.json()).then(data => {
            let pincode = data.address.postcode;
            if (pincode) document.getElementById("pincode_display").innerHTML = pincode;
        }).catch(err => { document.getElementById("pincode_display").innerHTML = "110001"; });
    }
    function showError(error) { document.getElementById("pincode_display").innerHTML = "110001"; }
    function changePincode() {
        let current = document.getElementById("pincode_display").innerHTML;
        let newPin = prompt("Enter your correct Pincode:", current);
        if(newPin != null && newPin.length > 0) {
            document.getElementById("pincode_display").innerHTML = newPin;
            alert("Location updated to " + newPin);
        }
    }
</script>