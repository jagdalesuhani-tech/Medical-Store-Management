<%@ page language="java" contentType="text/html; charset=ISO-8859-1" pageEncoding="ISO-8859-1"%>
<%@ page import="com.medical.entities.User" %>

<%
    User user = (User) session.getAttribute("current-user");
    if(user == null) {
        session.setAttribute("message", "Please login first!");
        response.sendRedirect("login.jsp");
        return;
    }
%>

<!DOCTYPE html>
<html>
<head>
    <title>My Profile - MediCare</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body style="background: #f1f3f6;">

    <%@ include file="components/navbar.jsp" %>

    <div class="container mt-5">
        
        <% 
            String msg = (String) session.getAttribute("message");
            if(msg != null) {
        %>
            <div class="alert alert-success alert-dismissible fade show">
                <strong>Success!</strong> <%= msg %>
                <button type="button" class="close" data-dismiss="alert">&times;</button>
            </div>
        <% 
            session.removeAttribute("message");
            } 
        %>

        <div class="row">
            <div class="col-md-6 offset-md-3">
                <div class="card shadow">
                    <div class="card-header bg-primary text-white text-center">
                        <h3><i class="fa fa-user-circle"></i> My Profile</h3>
                    </div>
                    <div class="card-body text-center">
                        <img src="img/user.png" class="img-fluid rounded-circle mb-3" style="max-width: 150px;">
                        
                        <h4 class="text-primary"><%= user.getUserName() %></h4>
                        
                        <table class="table table-bordered text-left mt-3">
                            <tr>
                                <th>Email</th>
                                <td><%= user.getUserEmail() %></td>
                            </tr>
                            <tr>
                                <th>Phone</th>
                                <td><%= user.getUserPhone() %></td>
                            </tr>
                            <tr>
                                <th>Address</th>
                                <td><%= user.getUserAddress() %></td>
                            </tr>
                            <tr>
                                <th>Type</th>
                                <td><span class="badge badge-info"><%= user.getUserType() %></span></td>
                            </tr>
                        </table>
                        
                        <button type="button" class="btn btn-warning mt-3" data-toggle="modal" data-target="#editProfileModal">
                            <i class="fa fa-edit"></i> Edit Details
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="editProfileModal" tabindex="-1" role="dialog">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header bg-warning">
            <h5 class="modal-title">Edit Profile</h5>
            <button type="button" class="close" data-dismiss="modal">
              <span>&times;</span>
            </button>
          </div>
          <div class="modal-body">
            
            <form action="EditProfileServlet" method="post">
                
                <div class="form-group">
                    <label>Name</label>
                    <input type="text" name="user_name" class="form-control" value="<%= user.getUserName() %>" required>
                </div>
                
                <div class="form-group">
                    <label>Phone Number</label>
                    <input type="text" name="user_phone" class="form-control" value="<%= user.getUserPhone() %>" required>
                </div>
                
                <div class="form-group">
                    <label>Shipping Address</label>
                    <textarea name="user_address" class="form-control" rows="3" required><%= user.getUserAddress() %></textarea>
                </div>

                <div class="text-center">
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
                
            </form>
            
          </div>
        </div>
      </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

</body>
</html>