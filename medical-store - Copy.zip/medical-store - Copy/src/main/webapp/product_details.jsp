<%@ page language="java" contentType="text/html; charset=ISO-8859-1" pageEncoding="ISO-8859-1"%>
<%@ page import="com.medical.helper.FactoryProvider" %>
<%@ page import="com.medical.dao.ProductDao" %>
<%@ page import="com.medical.entities.*" %>

<%
    // Get Product ID from URL
    int pid = Integer.parseInt(request.getParameter("pid"));
    ProductDao dao = new ProductDao(FactoryProvider.getFactory());
    Product p = dao.getProductById(pid);
%>

<!DOCTYPE html>
<html>
<head>
    <title><%= p.getpName() %> - Details</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/style.css">
    <style>
        .zoom-img {
            width: 100%;
            max-width: 400px;
            transition: transform 0.5s ease; /* CSS Animation */
            cursor: zoom-in;
        }
        .zoom-img:hover {
            transform: scale(1.3); /* The ZOOM Effect */
        }
        .img-container {
            overflow: hidden; /* Keeps the zoom inside the box */
            border: 1px solid #ddd;
            padding: 20px;
            text-align: center;
            background: #fff;
        }
        .back-btn {
            font-size: 14px;
            text-decoration: none;
            color: #6c757d;
            margin-bottom: 10px;
            display: inline-block;
        }
        .back-btn:hover {
            color: #343a40;
            text-decoration: underline;
        }
    </style>
</head>
<body style="background: #f1f3f6;">

    <%@ include file="components/navbar.jsp" %>

    <div class="container mt-4">
        
        <a href="index.jsp" class="back-btn">
            <i class="fa fa-arrow-left"></i> Back to Home
        </a>

        <div class="card shadow-sm">
            <div class="container-fluid">
                <div class="row">
                    
                    <div class="col-md-5 p-5 img-container">
                        <img src="img/products/<%= p.getpPhoto() %>" class="zoom-img" alt="<%= p.getpName() %>">
                    </div>
                    
                    <div class="col-md-7 p-5">
                        <h2 style="font-weight: 700;"><%= p.getpName() %></h2>
                        <p class="text-muted"><%= p.getCategory().getCategoryTitle() %></p>
                        
                        <h3 class="text-success">
                            &#8377; <%= p.getpPrice() %> 
                            <small class="text-muted" style="font-size: 18px; text-decoration: line-through;">&#8377;<%= (int)(p.getpPrice() * 1.2) %></small>
                            <span class="badge badge-warning ml-2" style="font-size: 14px;"><%= p.getpDiscount() %>% OFF</span>
                        </h3>
                        
                        <div class="mt-4">
                            <h5>Description:</h5>
                            <p style="font-size: 16px; line-height: 1.6; color: #555;"><%= p.getpDesc() %></p>
                        </div>
                        
                        <div class="mt-4">
                            <% if (p.getpQuantity() > 0) { %>
                                <a href="CartServlet?action=add&pid=<%= p.getpId() %>" class="btn btn-primary btn-lg px-4">
                                    <i class="fa fa-shopping-cart"></i> Add to Cart
                                </a>

                                <a href="CartServlet?action=add&pid=<%= p.getpId() %>&redirect=cart" class="btn btn-warning btn-lg px-4 text-white ml-2">
                                    <i class="fa fa-bolt"></i> Buy Now
                                </a>
                            <% } else { %>
                                <button class="btn btn-danger btn-lg" disabled>Out of Stock</button>
                            <% } %>
                        </div>
                        
                        <div class="row mt-4 text-muted small">
                            <div class="col-md-4"><i class="fa fa-truck"></i> Free Delivery</div>
                            <div class="col-md-4"><i class="fa fa-refresh"></i> 7 Days Return</div>
                            <div class="col-md-4"><i class="fa fa-lock"></i> Secure Payment</div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

</body>
</html>