<%@ page language="java" contentType="text/html; charset=ISO-8859-1" pageEncoding="ISO-8859-1"%>
<%@ page import="com.medical.helper.CartItem" %>
<%@ page import="com.medical.entities.User" %>
<%@ page import="java.util.List" %>

<%
    User user = (User) session.getAttribute("current-user");
    if(user == null) {
        session.setAttribute("message", "Login first to checkout!");
        response.sendRedirect("login.jsp");
        return;
    }
    
    List<CartItem> cart = (List<CartItem>) session.getAttribute("cart-list");
    if(cart == null || cart.isEmpty()) {
        session.setAttribute("message", "Your cart is empty.");
        response.sendRedirect("cart.jsp");
        return;
    }
    
    int totalAmount = 0;
    for(CartItem item : cart) {
        totalAmount += item.getTotalPrice();
    }
%>

<!DOCTYPE html>
<html>
<head>
    <title>Checkout - MediCare</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    
    <style>
        .checkout-card { box-shadow: 0 4px 8px rgba(0,0,0,0.1); border: none; padding: 20px; }
        .summary-card { background-color: #f8f9fa; padding: 20px; border-radius: 5px; }
    </style>
</head>
<body style="background: #f1f3f6;">

    <%@ include file="components/navbar.jsp" %>

    <div class="container mt-4 mb-5">
        <div class="row">
            
            <div class="col-md-8">
                <div class="card checkout-card">
                    <h4 class="mb-3">Shipping Details</h4>
                    <form id="payment-form">
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label>Name</label>
                                <input type="text" class="form-control" value="<%= user.getUserName() %>" readonly>
                            </div>
                            <div class="form-group col-md-6">
                                <label>Phone Number <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="phone" name="user_phone" value="<%= user.getUserPhone() %>" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Shipping Address <span class="text-danger">*</span></label>
                            <textarea class="form-control" id="address" name="user_address" rows="3" placeholder="Enter full address..." required><%= user.getUserAddress() %></textarea>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label>City <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="city" required>
                            </div>
                            <div class="form-group col-md-6">
                                <label>Pincode <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="pincode" required>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card summary-card">
                    <h4>Order Summary</h4>
                    <hr>
                    <div class="d-flex justify-content-between">
                        <span>Items (<%= cart.size() %>)</span>
                        <span>&#8377; <%= totalAmount %></span>
                    </div>
                    <div class="d-flex justify-content-between mt-2">
                        <span>Delivery</span>
                        <span class="text-success">FREE</span>
                    </div>
                    <hr>
                    <div class="d-flex justify-content-between" style="font-weight: bold; font-size: 18px;">
                        <span>Total Pay</span>
                        <span>&#8377; <%= totalAmount %></span>
                    </div>

                    <button onclick="startPayment(<%= totalAmount %>)" class="btn btn-primary btn-block mt-4 custom-bg">Pay Online (Razorpay)</button>
                    
                    <button onclick="processCOD()" class="btn btn-outline-secondary btn-block mt-2">Cash on Delivery</button>
                </div>
            </div>
            
        </div>
    </div>

    <script>
    // 1. HELPER FUNCTION TO VALIDATE FORM
    function validateForm() {
        var form = document.getElementById('payment-form');
        
        // This triggers the browser's default validation (red outlines, tooltips)
        if (form.checkValidity() === false) {
            form.reportValidity(); // Shows the "Please fill out this field" bubble
            return false;
        }
        return true;
    }

    // 2. CASH ON DELIVERY LOGIC
    function processCOD() {
        if (validateForm()) {
            // If valid, redirect to Servlet
            window.location.href = "OrderServlet";
        }
    }

    // 3. ONLINE PAYMENT LOGIC
    function startPayment(amount) {
        
        // Check validation FIRST
        if (!validateForm()) {
            return; // Stop if invalid
        }

        var options = {
            "key": "rzp_test_YourKeyHere", // REPLACE WITH YOUR KEY
            "amount": amount * 100, 
            "currency": "INR",
            "name": "MediCare Store",
            "description": "Medical Order Payment",
            "image": "img/logo.png",
            
            "handler": function (response){
                console.log(response.razorpay_payment_id);
                alert("Payment Successful! Payment ID: " + response.razorpay_payment_id);
                // Redirect to OrderServlet (maybe with a flag for online payment)
                window.location = "OrderServlet"; 
            },
            
            "prefill": {
                "name": "<%= user.getUserName() %>",
                "email": "<%= user.getUserEmail() %>",
                "contact": document.getElementById('phone').value // Use the updated phone value
            },
            "theme": {
                "color": "#3399cc"
            }
        };

        var rzp1 = new Razorpay(options);
        rzp1.on('payment.failed', function (response){
            alert("Payment Failed");
        });
        rzp1.open();
    }
    </script>

</body>
</html>