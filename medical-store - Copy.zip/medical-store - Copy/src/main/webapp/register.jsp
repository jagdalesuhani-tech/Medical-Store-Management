<%@ page language="java" contentType="text/html; charset=ISO-8859-1" pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="ISO-8859-1">
    <title>Register - MediCare</title>
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
    <style>
        /* 1. Import Poppins Font */
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap');

        /* 2. Background Theme */
        body {
            font-family: 'Poppins', sans-serif;
            background-image: url('img/body-bg.jpg'); /* Same background as Login */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            background-attachment: fixed;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px 0; /* Add padding for mobile scrolling */
        }

        /* 3. The Glass Card */
        .register-card {
            background: rgba(255, 255, 255, 0.94); /* Slightly less transparent for readability */
            padding: 40px 30px;
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 450px; /* Slightly wider than login */
            border: 1px solid #ffe3e8;
            position: relative;
            overflow: hidden;
        }

        /* Top Colored Bar */
        .register-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 5px;
            background: linear-gradient(90deg, #28a745, #007bff); /* Green to Blue for Registration */
        }

        /* Icon Circle */
        .icon-circle {
            width: 70px;
            height: 70px;
            background: #e8f5e9; /* Light Green bg */
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px auto;
            color: #28a745;
            font-size: 30px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }

        h3 { color: #333; font-weight: 700; text-align: center; margin-bottom: 5px; }
        p.subtitle { color: #777; font-size: 14px; text-align: center; margin-bottom: 25px; }

        /* Input Styling */
        .form-group { margin-bottom: 15px; position: relative; }
        .form-group label { font-size: 13px; font-weight: 600; color: #555; margin-bottom: 5px; display: block; }
        
        .input-with-icon { position: relative; }
        .input-with-icon i {
            position: absolute;
            left: 15px;
            top: 14px; /* Center vertically */
            color: #aaa;
            font-size: 16px;
        }

        /* Inputs */
        .form-control {
            padding-left: 45px;
            height: 45px;
            border-radius: 50px;
            border: 1px solid #e0e0e0;
            font-size: 14px;
            background: #fdfdfd;
        }
        .form-control:focus {
            border-color: #28a745;
            box-shadow: 0 0 0 3px rgba(40, 167, 69, 0.1);
        }

        /* Textarea specific */
        textarea.form-control {
            height: auto;
            border-radius: 15px; /* Less rounded for box */
            padding-top: 12px;
            padding-left: 45px;
        }

        /* Button */
        .btn-register {
            background: linear-gradient(135deg, #28a745, #218838); /* Green Gradient */
            border: none;
            width: 100%;
            height: 45px;
            border-radius: 50px;
            color: white;
            font-weight: 600;
            font-size: 16px;
            margin-top: 10px;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 5px 15px rgba(40, 167, 69, 0.3);
        }
        .btn-register:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(40, 167, 69, 0.4);
        }

        /* Links */
        .login-link { text-align: center; margin-top: 20px; font-size: 14px; color: #666; }
        .login-link a { color: #007bff; font-weight: 600; text-decoration: none; }
        .login-link a:hover { text-decoration: underline; }

        /* Error Message */
        .alert-custom { font-size: 13px; border-radius: 10px; padding: 10px; }
    </style>
</head>
<body>

    <div class="register-card">
        <div class="icon-circle">
            <i class="fa fa-user-plus"></i>
        </div>

        <h3>Create Account</h3>
        <p class="subtitle">Join us to order medicines online</p>

        <% 
            String message = (String)session.getAttribute("message");
            if(message != null){
        %>
            <div class="alert alert-danger alert-custom text-center">
                <%= message %>
            </div>
        <% 
            session.removeAttribute("message"); 
            }
        %>

        <form action="RegisterServlet" method="post">
            
            <div class="form-group">
                <label>Full Name</label>
                <div class="input-with-icon">
                    <i class="fa fa-user"></i>
                    <input type="text" name="user_name" class="form-control" placeholder="Enter your name" required>
                </div>
            </div>

            <div class="form-group">
                <label>Email Address</label>
                <div class="input-with-icon">
                    <i class="fa fa-envelope"></i>
                    <input type="email" name="user_email" class="form-control" placeholder="example@gmail.com" required>
                </div>
            </div>

            <div class="form-group">
                <label>Password</label>
                <div class="input-with-icon">
                    <i class="fa fa-lock"></i>
                    <input type="password" name="user_pass" class="form-control" placeholder="Create a strong password" required>
                </div>
            </div>

            <div class="form-group">
                <label>Phone Number</label>
                <div class="input-with-icon">
                    <i class="fa fa-phone"></i>
                    <input type="number" name="user_phone" class="form-control" placeholder="Enter mobile number" required>
                </div>
            </div>

            <div class="form-group">
                <label>Delivery Address</label>
                <div class="input-with-icon">
                    <i class="fa fa-map-marker" style="top: 15px;"></i> <textarea name="user_address" class="form-control" rows="3" placeholder="Enter full address for delivery" required></textarea>
                </div>
            </div>

            <button type="submit" class="btn-register">Register Now</button>
        </form>

        <div class="login-link">
            Already have an account? <a href="login.jsp">Login Here</a>
        </div>
    </div>

</body>
</html>