<%@ page language="java" contentType="text/html; charset=ISO-8859-1" pageEncoding="ISO-8859-1"%>
<%@ page import="com.medical.helper.FactoryProvider" %>
<%@ page import="com.medical.dao.ProductDao" %>
<%@ page import="com.medical.dao.CategoryDao" %>
<%@ page import="com.medical.entities.*" %>
<%@ page import="com.medical.helper.Helper" %>
<%@ page import="java.util.List" %>

<!DOCTYPE html>
<html>
<head>
    <meta charset="ISO-8859-1">
    <title>MediCare Store - Home</title>
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/style.css">
    
    <style>
        /* Modern Font */
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap');

        /* ========================================= */
        /* 1. BODY BACKGROUND (Rest of the page)     */
        /* ========================================= */
        body {
            font-family: 'Poppins', sans-serif !important;
            
            /* CHANGE 'body-bg.jpg' to your filename */
            background-image: url('img/body-bg.jpg?v=2'); 
            
            /* This makes the background stay still while you scroll (Professional Look) */
            background-attachment: scroll;
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }

        /* ========================================= */
        /* 2. BANNER GIF (Top 25% Off Section)       */
        /* ========================================= */
        .hero-banner {
            /* Keep your GIF here */
            background: linear-gradient(rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.4)), 
                        url('img/banner.gif'); 
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            color: white;
            border-radius: 15px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
            padding: 80px 40px;
        }

        /* Product Cards */
        .product-card {
            border: 1px solid #f0f0f0;
            border-radius: 12px;
            transition: all 0.3s ease;
            background: #ffe3e8; /* Slight transparency to pop against bg */
            overflow: hidden;
        }
        .product-card:hover {
            box-shadow: 0 15px 30px rgba(0,0,0,0.1);
            transform: translateY(-5px);
            border-color: #32aeb1;
        }
        .card-img-wrapper {
            height: 180px;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            background: white;
        }
        .card-img-wrapper img {
            max-height: 85%;
            max-width: 85%;
            transition: transform 0.4s ease;
        }
        .product-card:hover .card-img-wrapper img { transform: scale(1.08); }
        .price-text { font-size: 18px; font-weight: 700; color: #28a745; }
        .discount-badge { font-size: 11px; background: #ffebee; color: #c62828; padding: 3px 8px; border-radius: 4px; margin-left: 5px; font-weight: 600; }
        .btn { border-radius: 50px; font-weight: 500; transition: all 0.3s ease; }

        /* Chatbot Styles */
        .chat-btn { position: fixed; bottom: 30px; right: 30px; background: #007bff; color: white; width: 60px; height: 60px; border-radius: 50%; text-align: center; line-height: 60px; font-size: 28px; cursor: pointer; box-shadow: 0 4px 15px rgba(0,123,255,0.4); z-index: 9999; }
        .chat-box { display: none; position: fixed; bottom: 100px; right: 30px; width: 350px; height: 450px; background: white; border-radius: 15px; box-shadow: 0 10px 30px rgba(0,0,0,0.2); z-index: 9999; flex-direction: column; overflow: hidden; border: 1px solid #e0e0e0; }
        .chat-header { background: #007bff; color: white; padding: 15px; font-weight: 600; display: flex; justify-content: space-between; align-items: center; }
        .chat-body { flex: 1; padding: 15px; overflow-y: auto; background: #f9f9f9; font-size: 14px; }
        .chat-footer { padding: 15px; background: white; border-top: 1px solid #eee; }
        .bot-msg { background: #e9ecef; color: #333; padding: 10px 15px; border-radius: 15px; border-bottom-left-radius: 2px; margin-bottom: 10px; max-width: 80%; align-self: flex-start; }
        .user-msg { background: #007bff; color: white; padding: 10px 15px; border-radius: 15px; border-bottom-right-radius: 2px; margin-bottom: 10px; max-width: 80%; margin-left: auto; text-align: right; }
    </style>
</head>
<body>

    <%@ include file="components/navbar.jsp" %>
    <%@ include file="components/message.jsp" %>

    <div class="container mt-4">
        
        <div class="row mb-5">
            <div class="col-md-12">
                <div class="hero-banner">
                    <div class="col-md-8 px-0">
                        <h1 class="display-4 font-weight-bold">Healthy Life, Happy Life</h1>
                        <p class="lead my-3">Get flat <strong>25% OFF</strong> on all prescription medicines. Code: <strong>WELCOME25</strong></p>
                        <a href="#products-section" class="btn btn-light text-success font-weight-bold px-4 py-2 mt-2 shadow-sm">Shop Now</a>
                    </div>
                </div>
            </div>
        </div>

        <div class="row" id="products-section">
            <%
                String cat = request.getParameter("category");
                String search = request.getParameter("search");
                
                ProductDao dao = new ProductDao(FactoryProvider.getFactory());
                List<Product> list = dao.getAllProducts();
                
                String sectionTitle = "Featured Products";
                if (cat != null && !cat.equals("all")) { sectionTitle = "Filtered Results"; } 
                else if (search != null && !search.trim().isEmpty()) { sectionTitle = "Search Results for '" + search + "'"; }
            %>

            <div class="col-md-12">
                <h4 class="mb-4" style="font-weight: 700; color: #444;"><%= sectionTitle %></h4>
                
                <div class="row">
                    <% 
                        boolean isFound = false;
                        for (Product p : list) { 
                            if(cat != null && !cat.equals("all")) {
                                try { if(p.getCategory().getCategoryId() != Integer.parseInt(cat.trim())) continue; } catch(Exception e) {}
                            }
                            if (search != null && !search.trim().isEmpty()) {
                                if (!p.getpName().toLowerCase().contains(search.trim().toLowerCase())) continue;
                            }
                            isFound = true;
                    %>
                    
                    <div class="col-lg-3 col-md-4 col-sm-6 mb-4"> 
                        <div class="card product-card h-100">
                            
                            <a href="product_details.jsp?pid=<%= p.getpId() %>" class="card-img-wrapper">
                                <img src="<%= request.getContextPath() %>/img/products/<%= p.getpPhoto() %>" alt="<%= p.getpName() %>">
                            </a>
                            
                            <div class="card-body p-3 d-flex flex-column">
                                <h6 class="card-title text-truncate mb-1">
                                    <a href="product_details.jsp?pid=<%= p.getpId() %>" class="text-dark text-decoration-none">
                                        <%= p.getpName() %>
                                    </a>
                                </h6>
                                <p class="card-text text-muted small mb-2"><%= Helper.get10Words(p.getpDesc()) %></p>
                                
                                <div class="mt-auto">
                                    <% if (p.getpQuantity() > 0) { %>
                                        <div class="mb-3">
                                            <span class="price-text">&#8377; <%= p.getpPrice() %></span>
                                            <span class="text-muted small ml-1"><del>&#8377;<%= (int)(p.getpPrice() * 1.2) %></del></span>
                                            <span class="discount-badge"><%= p.getpDiscount() %>% OFF</span>
                                        </div>
                                        <div class="d-flex justify-content-between">
                                            <a href="product_details.jsp?pid=<%= p.getpId() %>" class="btn btn-outline-primary btn-sm flex-fill mr-1">View</a>
                                            <a href="CartServlet?action=add&pid=<%= p.getpId() %>" class="btn btn-info btn-sm flex-fill ml-1 text-white">Add</a>
                                        </div>
                                    <% } else { %>
                                        <div class="mb-3">
                                            <span class="text-muted small"><s>&#8377; <%= p.getpPrice() %></s></span>
                                            <span class="badge badge-danger ml-2">Out of Stock</span>
                                        </div>
                                        <button class="btn btn-secondary btn-block btn-sm" disabled>Unavailable</button>
                                    <% } %>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <% } if (!isFound) { %>
                        <div class="col-12 text-center py-5">
                            <i class="fa fa-search fa-3x text-muted mb-3"></i>
                            <h3 class="text-muted">No medicines found.</h3>
                            <a href="index.jsp?category=all" class="btn btn-primary mt-2">View All Products</a>
                        </div>
                    <% } %>
                </div>
            </div>
        </div>
    </div>
    
    <div class="chat-btn" onclick="toggleChat()"><i class="fa fa-comments"></i></div>
    <div class="chat-box" id="chat-box">
        <div class="chat-header"><span><i class="fa fa-robot mr-2"></i>MediBot AI</span> <span style="cursor:pointer; font-size: 20px;" onclick="toggleChat()">&times;</span></div>
        <div class="chat-body" id="chat-body"><div class="bot-msg">Hello! I am your AI Health Assistant. Tell me your symptom (e.g., Fever, Cold) and I'll suggest medicines!</div></div>
        <div class="chat-footer">
            <div class="input-group">
                <input type="text" id="chat-input" class="form-control" placeholder="Type a symptom..." onkeypress="handleEnter(event)">
                <div class="input-group-append"><button class="btn btn-primary" onclick="sendMessage()"><i class="fa fa-paper-plane"></i></button></div>
            </div>
        </div>
    </div>
    
    <%@ include file="components/footer.jsp" %>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script>
        function toggleChat() { var box = document.getElementById("chat-box"); box.style.display = (box.style.display === "none" || box.style.display === "") ? "flex" : "none"; }
        function handleEnter(e) { if(e.keyCode === 13) sendMessage(); }
        function sendMessage() {
            var input = document.getElementById("chat-input"); var msg = input.value; if(msg.trim() === "") return;
            var body = document.getElementById("chat-body");
            var userDiv = document.createElement("div"); userDiv.className = "user-msg"; userDiv.innerText = msg; body.appendChild(userDiv);
            input.value = ""; body.scrollTop = body.scrollHeight;
            var loadingDiv = document.createElement("div"); loadingDiv.className = "bot-msg"; loadingDiv.id = "loading-msg"; loadingDiv.innerHTML = "<em>Thinking...</em>"; body.appendChild(loadingDiv); body.scrollTop = body.scrollHeight;
            fetch("BotServlet?query=" + msg).then(response => response.text()).then(text => {
                var loadMsg = document.getElementById("loading-msg"); if(loadMsg) loadMsg.remove();
                var botDiv = document.createElement("div"); botDiv.className = "bot-msg"; botDiv.innerHTML = text; body.appendChild(botDiv); body.scrollTop = body.scrollHeight;
            });
        }
    </script>
</body>
</html>